import React, { useState, useEffect } from 'react';
import { Navbar } from './components/Navbar';
import { SearchHeader } from './components/SearchHeader';
import { TargetSummaryCard } from './components/TargetSummaryCard';
import { FootprintGraph } from './components/FootprintGraph';
import { ProfilesGrid } from './components/ProfilesGrid';
import { BreachRecordsTable } from './components/BreachRecordsTable';
import { ThreatVectorsCard } from './components/ThreatVectorsCard';
import { TimelineView } from './components/TimelineView';
import { RawDataDrawer } from './components/RawDataDrawer';
import { ImageForensicsView } from './components/ImageForensicsView';
import { ExportReportModal } from './components/ExportReportModal';
import { ComplianceModal } from './components/ComplianceModal';
import { HistoryDrawer } from './components/HistoryDrawer';
import { AnonymizationControlBar } from './components/AnonymizationControlBar';
import { PhoneIdentityCard } from './components/PhoneIdentityCard';
import { DEMO_TARGETS, DemoTarget } from './data/mockDemos';
import { OsintResult, QueryType, ScanDepth, SearchHistoryItem, AnonymizationOptions, AnonymizationLevel } from './types';
import { DEFAULT_ANONYMIZATION_OPTIONS, anonymizeOsintResult } from './utils/anonymizer';
import { Shield, UserCheck, ShieldAlert, Network, Clock, Zap, Terminal, AlertTriangle, Sparkles, CheckCircle2, Camera, Search, Layers } from 'lucide-react';

export default function App() {
  const [currentResult, setCurrentResult] = useState<OsintResult | null>(DEMO_TARGETS[0].data);
  const [isScanning, setIsScanning] = useState<boolean>(false);
  const [scanMessage, setScanMessage] = useState<string>('');
  
  // Investigation Module Section: 'osint' or 'imageForensics'
  const [investigationModule, setInvestigationModule] = useState<'osint' | 'imageForensics'>('osint');
  
  // OSINT Active Tab
  const [activeTab, setActiveTab] = useState<'overview' | 'profiles' | 'breaches' | 'timeline' | 'threats' | 'raw'>('overview');
  
  // Real-Time Anonymization State
  const [anonymizationOptions, setAnonymizationOptions] = useState<AnonymizationOptions>(() => {
    try {
      const saved = localStorage.getItem('spectra_osint_anonymization');
      if (saved) return JSON.parse(saved);
    } catch (e) {
      console.error(e);
    }
    return DEFAULT_ANONYMIZATION_OPTIONS;
  });

  useEffect(() => {
    try {
      localStorage.setItem('spectra_osint_anonymization', JSON.stringify(anonymizationOptions));
    } catch (e) {
      console.error(e);
    }
  }, [anonymizationOptions]);

  // Compute live anonymized OSINT result
  const displayResult = currentResult ? anonymizeOsintResult(currentResult, anonymizationOptions) : null;

  // Modals & Drawers
  const [showExportModal, setShowExportModal] = useState(false);
  const [showComplianceModal, setShowComplianceModal] = useState(false);
  const [showHistoryDrawer, setShowHistoryDrawer] = useState(false);

  // Search History Locker
  const [history, setHistory] = useState<SearchHistoryItem[]>(() => {
    try {
      const saved = localStorage.getItem('spectra_osint_history');
      if (saved) return JSON.parse(saved);
    } catch (e) {
      console.error(e);
    }
    return DEMO_TARGETS.map((d) => ({
      id: d.id,
      query: d.query,
      queryType: d.type,
      timestamp: d.data.timestamp,
      riskScore: d.data.targetSummary.overallRiskScore,
      profilesCount: d.data.profiles.length,
      breachesCount: d.data.breaches.length,
    }));
  });

  useEffect(() => {
    try {
      localStorage.setItem('spectra_osint_history', JSON.stringify(history));
    } catch (e) {
      console.error(e);
    }
  }, [history]);

  // Execute Search via Server API
  const handleSearch = async (query: string, type: QueryType, depth: ScanDepth) => {
    setInvestigationModule('osint');
    setIsScanning(true);
    setScanMessage('Initializing OSINT Crawlers & Grounded Web Engine...');

    const messages = [
      'Scanning 300+ social platforms & developer handles...',
      'Cross-referencing darknet leak collections & breach indexes...',
      'Analyzing WHOIS domain registrations & carrier routing...',
      'Computing threat vectors & calculating identity risk index...',
      'Applying real-time privacy anonymization filters...',
      'Compiling grounded report synthesis...',
    ];

    let msgIdx = 0;
    const interval = setInterval(() => {
      msgIdx = (msgIdx + 1) % messages.length;
      setScanMessage(messages[msgIdx]);
    }, 700);

    try {
      const res = await fetch('/api/osint/search', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ query, type, depth }),
      });

      if (!res.ok) {
        throw new Error(`Server returned HTTP ${res.status}`);
      }

      const data: OsintResult = await res.json();
      setCurrentResult(data);

      // Add to locker history
      const newHistoryItem: SearchHistoryItem = {
        id: `hist-${Date.now()}`,
        query: data.query,
        queryType: data.queryType,
        timestamp: data.timestamp,
        riskScore: data.targetSummary.overallRiskScore,
        profilesCount: data.profiles.length,
        breachesCount: data.breaches.length,
      };

      setHistory((prev) => [newHistoryItem, ...prev.filter((h) => h.query.toLowerCase() !== data.query.toLowerCase())]);
    } catch (err) {
      console.error('OSINT search error:', err);
      // Fallback to synthetic search if server encounters issue
      const demoFallback = DEMO_TARGETS.find((d) => d.query.toLowerCase() === query.toLowerCase());
      if (demoFallback) {
        setCurrentResult(demoFallback.data);
      }
    } finally {
      clearInterval(interval);
      setIsScanning(false);
    }
  };

  const handleSelectDemo = (demo: DemoTarget) => {
    setInvestigationModule('osint');
    setCurrentResult(demo.data);
    setActiveTab('overview');
  };

  const handleSelectHistoryItem = (item: SearchHistoryItem) => {
    setInvestigationModule('osint');
    const matchingDemo = DEMO_TARGETS.find((d) => d.query.toLowerCase() === item.query.toLowerCase());
    if (matchingDemo) {
      setCurrentResult(matchingDemo.data);
    } else {
      handleSearch(item.query, item.queryType, 'deep');
    }
    setShowHistoryDrawer(false);
  };

  const handleToggleNavbarAnonymization = () => {
    setAnonymizationOptions((prev) => {
      let nextLevel: AnonymizationLevel = 'PARTIAL';
      if (prev.level === 'PARTIAL') nextLevel = 'FULL';
      else if (prev.level === 'FULL') nextLevel = 'OFF';
      else nextLevel = 'PARTIAL';

      return {
        ...prev,
        level: nextLevel,
        maskNames: nextLevel !== 'OFF',
        maskLocations: nextLevel !== 'OFF',
        maskContacts: nextLevel !== 'OFF',
        maskHandles: nextLevel !== 'OFF',
        maskNetwork: nextLevel !== 'OFF',
      };
    });
  };

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col font-sans selection:bg-cyan-500 selection:text-slate-950">
      
      {/* Top Navbar */}
      <Navbar
        onOpenHistory={() => setShowHistoryDrawer(true)}
        onOpenCompliance={() => setShowComplianceModal(true)}
        onOpenExport={() => setShowExportModal(true)}
        isScanning={isScanning}
        historyCount={history.length}
        hasResult={!!currentResult}
        anonymizationLevel={anonymizationOptions.level}
        onToggleAnonymization={handleToggleNavbarAnonymization}
      />

      {/* Main Search Hero Area */}
      <SearchHeader
        onSearch={handleSearch}
        onSelectDemo={handleSelectDemo}
        onSelectImageForensics={() => setInvestigationModule('imageForensics')}
        isScanning={isScanning}
      />

      {/* Module Switcher Section Bar */}
      <div className="bg-slate-900/80 border-b border-slate-800 py-3">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex flex-wrap items-center justify-between gap-4 font-mono text-xs">
          <div className="flex items-center space-x-2">
            <span className="text-slate-500 uppercase font-bold text-[11px]">Investigation Section:</span>
            
            <button
              onClick={() => setInvestigationModule('osint')}
              className={`px-4 py-2 rounded-xl font-bold transition flex items-center space-x-2 ${
                investigationModule === 'osint'
                  ? 'bg-cyan-600 text-white shadow-md shadow-cyan-600/30'
                  : 'bg-slate-950 text-slate-400 hover:text-slate-200 border border-slate-800'
              }`}
            >
              <Search className="w-4 h-4 text-cyan-300" />
              <span>Digital Footprint Recon (Email, Phone, Domain)</span>
            </button>

            <button
              onClick={() => setInvestigationModule('imageForensics')}
              className={`px-4 py-2 rounded-xl font-bold transition flex items-center space-x-2 ${
                investigationModule === 'imageForensics'
                  ? 'bg-purple-600 text-white shadow-md shadow-purple-600/30'
                  : 'bg-slate-950 text-slate-400 hover:text-slate-200 border border-slate-800'
              }`}
            >
              <Camera className="w-4 h-4 text-purple-300" />
              <span>Real-Time Image & Photo Forensics (EXIF & Geotags)</span>
            </button>
          </div>

          <div className="hidden md:flex items-center space-x-2 text-slate-400 text-[11px]">
            <Sparkles className="w-3.5 h-3.5 text-cyan-400" />
            <span>Privacy Mask Active: <strong className="text-cyan-400">{anonymizationOptions.level}</strong></span>
          </div>
        </div>
      </div>

      {/* Main Content Dashboard Area */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-6">
        
        {/* Loading Overlay State */}
        {isScanning && (
          <div className="bg-slate-900 border border-slate-800 rounded-2xl p-10 text-center font-mono space-y-4 shadow-2xl animate-pulse">
            <div className="w-16 h-16 rounded-2xl bg-cyan-950 border border-cyan-800 text-cyan-400 flex items-center justify-center mx-auto shadow-lg shadow-cyan-500/20">
              <Zap className="w-8 h-8 animate-spin text-cyan-400" />
            </div>
            <div>
              <h3 className="text-xl font-bold text-slate-100">LAUNCHING GROUNDED OSINT RECON</h3>
              <p className="text-cyan-400 text-sm mt-1">{scanMessage}</p>
            </div>
            <div className="max-w-md mx-auto w-full bg-slate-950 h-2 rounded-full overflow-hidden border border-slate-800">
              <div className="bg-gradient-to-r from-cyan-500 via-blue-500 to-indigo-500 h-full w-2/3 animate-pulse"></div>
            </div>
          </div>
        )}

        {/* Section 1: Image Forensics Investigation Module */}
        {!isScanning && investigationModule === 'imageForensics' && (
          <ImageForensicsView anonymizationOptions={anonymizationOptions} />
        )}

        {/* Section 2: OSINT Digital Footprint Investigation Module */}
        {!isScanning && investigationModule === 'osint' && displayResult && (
          <div className="space-y-6">
            
            {/* Real-Time Privacy & Anonymization Toolbar */}
            <AnonymizationControlBar
              options={anonymizationOptions}
              onChangeOptions={setAnonymizationOptions}
            />

            {/* Phone Mobile Identification & Caller Intel Card */}
            <PhoneIdentityCard result={displayResult} />

            {/* Primary Target Summary Card */}
            <TargetSummaryCard result={displayResult} />

            {/* Navigation Tabs Bar */}
            <div className="flex flex-wrap items-center gap-2 border-b border-slate-800 pb-3 font-mono text-xs sm:text-sm">
              <button
                onClick={() => setActiveTab('overview')}
                className={`px-4 py-2 rounded-xl font-bold transition flex items-center space-x-2 ${
                  activeTab === 'overview'
                    ? 'bg-cyan-600 text-white shadow-md shadow-cyan-600/30'
                    : 'bg-slate-900 text-slate-400 hover:text-slate-200 hover:bg-slate-800 border border-slate-800'
                }`}
              >
                <Network className="w-4 h-4" />
                <span>Footprint Map & Overview</span>
              </button>

              <button
                onClick={() => setActiveTab('profiles')}
                className={`px-4 py-2 rounded-xl font-bold transition flex items-center space-x-2 ${
                  activeTab === 'profiles'
                    ? 'bg-cyan-600 text-white shadow-md shadow-cyan-600/30'
                    : 'bg-slate-900 text-slate-400 hover:text-slate-200 hover:bg-slate-800 border border-slate-800'
                }`}
              >
                <UserCheck className="w-4 h-4" />
                <span>Discovered Profiles ({displayResult.profiles.length})</span>
              </button>

              <button
                onClick={() => setActiveTab('breaches')}
                className={`px-4 py-2 rounded-xl font-bold transition flex items-center space-x-2 ${
                  activeTab === 'breaches'
                    ? 'bg-cyan-600 text-white shadow-md shadow-cyan-600/30'
                    : 'bg-slate-900 text-slate-400 hover:text-slate-200 hover:bg-slate-800 border border-slate-800'
                }`}
              >
                <ShieldAlert className="w-4 h-4 text-red-400" />
                <span>Data Breaches ({displayResult.breaches.length})</span>
              </button>

              <button
                onClick={() => setActiveTab('threats')}
                className={`px-4 py-2 rounded-xl font-bold transition flex items-center space-x-2 ${
                  activeTab === 'threats'
                    ? 'bg-cyan-600 text-white shadow-md shadow-cyan-600/30'
                    : 'bg-slate-900 text-slate-400 hover:text-slate-200 hover:bg-slate-800 border border-slate-800'
                }`}
              >
                <Zap className="w-4 h-4 text-amber-400" />
                <span>Threat Vectors & Defense</span>
              </button>

              <button
                onClick={() => setActiveTab('timeline')}
                className={`px-4 py-2 rounded-xl font-bold transition flex items-center space-x-2 ${
                  activeTab === 'timeline'
                    ? 'bg-cyan-600 text-white shadow-md shadow-cyan-600/30'
                    : 'bg-slate-900 text-slate-400 hover:text-slate-200 hover:bg-slate-800 border border-slate-800'
                }`}
              >
                <Clock className="w-4 h-4" />
                <span>Timeline</span>
              </button>

              <button
                onClick={() => setActiveTab('raw')}
                className={`px-4 py-2 rounded-xl font-bold transition flex items-center space-x-2 ${
                  activeTab === 'raw'
                    ? 'bg-cyan-600 text-white shadow-md shadow-cyan-600/30'
                    : 'bg-slate-900 text-slate-400 hover:text-slate-200 hover:bg-slate-800 border border-slate-800'
                }`}
              >
                <Terminal className="w-4 h-4" />
                <span>Raw OSINT JSON</span>
              </button>
            </div>

            {/* Active Tab Content */}
            {activeTab === 'overview' && (
              <div className="space-y-6">
                <FootprintGraph result={displayResult} />
                <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                  <ProfilesGrid profiles={displayResult.profiles.slice(0, 6)} />
                  <ThreatVectorsCard
                    threatVectors={displayResult.threatVectors}
                    recommendations={displayResult.recommendations}
                  />
                </div>
              </div>
            )}

            {activeTab === 'profiles' && (
              <ProfilesGrid profiles={displayResult.profiles} />
            )}

            {activeTab === 'breaches' && (
              <BreachRecordsTable breaches={displayResult.breaches} />
            )}

            {activeTab === 'threats' && (
              <ThreatVectorsCard
                threatVectors={displayResult.threatVectors}
                recommendations={displayResult.recommendations}
              />
            )}

            {activeTab === 'timeline' && (
              <TimelineView timeline={displayResult.timeline} />
            )}

            {activeTab === 'raw' && (
              <RawDataDrawer result={displayResult} />
            )}

          </div>
        )}

      </main>

      {/* Footer */}
      <footer className="border-t border-slate-800/80 bg-slate-900/60 py-6 text-xs font-mono text-slate-400 text-center">
        <div className="max-w-7xl mx-auto px-4 flex flex-col sm:flex-row items-center justify-between gap-3">
          <span>SPECTRA OSINT ENGINE v3.6 • PRIVACY-COMPLIANT INTEL</span>
          <span>Authorized Security Research & Digital Footprint Reconnaissance</span>
        </div>
      </footer>

      {/* Modals & Drawers */}
      {showExportModal && displayResult && (
        <ExportReportModal
          result={currentResult!}
          initialAnonymizationOptions={anonymizationOptions}
          onClose={() => setShowExportModal(false)}
        />
      )}

      {showComplianceModal && (
        <ComplianceModal onClose={() => setShowComplianceModal(false)} />
      )}

      {showHistoryDrawer && (
        <HistoryDrawer
          history={history}
          onSelectHistoryItem={handleSelectHistoryItem}
          onClearHistory={() => setHistory([])}
          onClose={() => setShowHistoryDrawer(false)}
        />
      )}

    </div>
  );
}
