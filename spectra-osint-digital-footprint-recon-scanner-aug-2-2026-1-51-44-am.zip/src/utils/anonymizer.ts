import { OsintResult, AnonymizationOptions, AnonymizationLevel, SocialProfile, BreachRecord, CarrierInfo, DomainWhois, TimelineEvent, ThreatVector, NetworkNode, ImageForensicResult } from '../types';

export const DEFAULT_ANONYMIZATION_OPTIONS: AnonymizationOptions = {
  level: 'OFF',
  maskNames: false,
  maskLocations: false,
  maskContacts: false,
  maskHandles: false,
  maskNetwork: false,
};

/**
 * Anonymize Image Forensic Result according to privacy options
 */
export function anonymizeImageForensicResult(
  forensic: ImageForensicResult,
  options: AnonymizationOptions
): ImageForensicResult {
  if (!forensic || options.level === 'OFF') return forensic;

  const level = options.level;

  // Mask Device Data
  const device = {
    ...forensic.device,
    serialNumber: forensic.device.serialNumber && options.maskHandles ? maskHandle(forensic.device.serialNumber, level) : forensic.device.serialNumber,
    deviceOwner: forensic.device.deviceOwner && options.maskNames ? maskName(forensic.device.deviceOwner, level) : forensic.device.deviceOwner,
  };

  // Mask GPS Data
  const gps = {
    ...forensic.gps,
    latitude: options.maskLocations && forensic.gps.latitude ? Number((forensic.gps.latitude).toFixed(level === 'FULL' ? 0 : 2)) : forensic.gps.latitude,
    longitude: options.maskLocations && forensic.gps.longitude ? Number((forensic.gps.longitude).toFixed(level === 'FULL' ? 0 : 2)) : forensic.gps.longitude,
    locationName: options.maskLocations && forensic.gps.locationName ? maskLocation(forensic.gps.locationName, level) : forensic.gps.locationName,
  };

  // Context for text masking
  const context = {
    fullName: forensic.device.deviceOwner,
    location: forensic.gps.locationName,
  };

  return {
    ...forensic,
    device,
    gps,
    forensicSummary: maskText(forensic.forensicSummary, options, context),
    privacyRecommendations: forensic.privacyRecommendations.map((r) => maskText(r, options, context)),
  };
}

/**
 * Partial masking helper for names
 * e.g., "Johnathan Doe" -> "J******** D**"
 */
export function maskName(name: string, level: AnonymizationLevel): string {
  if (!name || level === 'OFF') return name;
  if (level === 'FULL') return '[REDACTED_NAME]';

  return name
    .split(/\s+/)
    .map((word) => {
      if (word.length <= 1) return word;
      if (word.length === 2) return `${word[0]}*`;
      return `${word[0]}${'*'.repeat(word.length - 2)}${word[word.length - 1]}`;
    })
    .join(' ');
}

/**
 * Masking helper for Email addresses
 * e.g., "john.doe@gmail.com" -> "j***e@gmail.com" (PARTIAL) or "[REDACTED_EMAIL]" (FULL)
 */
export function maskEmail(email: string, level: AnonymizationLevel): string {
  if (!email || level === 'OFF') return email;
  if (level === 'FULL') return '[REDACTED_EMAIL]';

  const parts = email.split('@');
  if (parts.length !== 2) return email;

  const [user, domain] = parts;
  let maskedUser = user;
  if (user.length <= 2) {
    maskedUser = `${user[0]}*`;
  } else {
    maskedUser = `${user[0]}${'*'.repeat(Math.max(2, user.length - 2))}${user[user.length - 1]}`;
  }

  return `${maskedUser}@${domain}`;
}

/**
 * Masking helper for Phone Numbers
 * e.g., "+1 (555) 234-5678" -> "+1 (***) ***-5678" (PARTIAL) or "[REDACTED_PHONE]" (FULL)
 */
export function maskPhone(phone: string, level: AnonymizationLevel): string {
  if (!phone || level === 'OFF') return phone;
  if (level === 'FULL') return '[REDACTED_PHONE]';

  const digits = phone.replace(/\D/g, '');
  if (digits.length < 7) return '***-***';

  const last4 = digits.slice(-4);
  const countryCode = phone.startsWith('+') ? phone.slice(0, 3) : '';
  return `${countryCode} (***) ***-${last4}`;
}

/**
 * Masking helper for Locations/Addresses
 * e.g., "San Francisco, CA" -> "San F********, CA" (PARTIAL) or "[REDACTED_LOCATION]" (FULL)
 */
export function maskLocation(location: string, level: AnonymizationLevel): string {
  if (!location || level === 'OFF') return location;
  if (level === 'FULL') return '[REDACTED_LOCATION]';

  const parts = location.split(/,\s*/);
  return parts
    .map((part) => {
      const words = part.split(/\s+/);
      return words
        .map((w) => {
          if (w.length <= 2) return w; // e.g. state code "CA" or "NY"
          return `${w[0]}${'*'.repeat(Math.max(2, w.length - 2))}${w[w.length - 1]}`;
        })
        .join(' ');
    })
    .join(', ');
}

/**
 * Masking helper for Usernames / Handles
 * e.g., "cyber_hunter99" -> "c**********99" (PARTIAL) or "[REDACTED_HANDLE]" (FULL)
 */
export function maskHandle(handle: string, level: AnonymizationLevel): string {
  if (!handle || level === 'OFF') return handle;
  if (level === 'FULL') return '[REDACTED_HANDLE]';

  if (handle.length <= 3) return `${handle[0]}**`;
  return `${handle[0]}${'*'.repeat(Math.max(2, handle.length - 3))}${handle.slice(-2)}`;
}

/**
 * Masking helper for IP addresses
 * e.g., "192.168.1.100" -> "192.168.x.x" (PARTIAL) or "[REDACTED_IP]" (FULL)
 */
export function maskIp(ip: string, level: AnonymizationLevel): string {
  if (!ip || level === 'OFF') return ip;
  if (level === 'FULL') return '[REDACTED_IP]';

  const parts = ip.split('.');
  if (parts.length === 4) {
    return `${parts[0]}.${parts[1]}.x.x`;
  }
  return ip.replace(/\.[0-9]+/g, '.x');
}

/**
 * Intelligently mask embedded sensitive identifiers in block text
 */
export function maskText(
  text: string,
  options: AnonymizationOptions,
  context?: { fullName?: string; query?: string; location?: string }
): string {
  if (!text || options.level === 'OFF') return text;

  let result = text;
  const level = options.level;

  // 1. Context Specific Replacements if provided
  if (options.maskNames && context?.fullName && context.fullName.length > 2) {
    const masked = maskName(context.fullName, level);
    result = result.replaceAll(context.fullName, masked);
  }

  if (options.maskLocations && context?.location && context.location.length > 2) {
    const masked = maskLocation(context.location, level);
    result = result.replaceAll(context.location, masked);
  }

  if (context?.query && context.query.length > 3) {
    // If query is an email
    if (context.query.includes('@') && options.maskContacts) {
      result = result.replaceAll(context.query, maskEmail(context.query, level));
    } else if (/^[0-9+() -]{7,}$/.test(context.query) && options.maskContacts) {
      result = result.replaceAll(context.query, maskPhone(context.query, level));
    } else if (options.maskHandles) {
      result = result.replaceAll(context.query, maskHandle(context.query, level));
    }
  }

  // 2. Generic Regex Replacements in block text
  // Email regex
  if (options.maskContacts) {
    result = result.replace(
      /[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}/g,
      (email) => maskEmail(email, level)
    );

    // Phone number regex
    result = result.replace(
      /(\+?\d{1,3}[\s-]?)?\(?\d{3}\)?[\s-]?\d{3}[\s-]?\d{4}/g,
      (phone) => maskPhone(phone, level)
    );
  }

  // IP Address regex
  if (options.maskNetwork) {
    result = result.replace(
      /\b(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\b/g,
      (ip) => maskIp(ip, level)
    );
  }

  return result;
}

/**
 * Sanitize an entire OsintResult object in real time based on AnonymizationOptions
 */
export function anonymizeOsintResult(
  result: OsintResult,
  options: AnonymizationOptions
): OsintResult {
  if (!result || options.level === 'OFF') return result;

  const level = options.level;
  const { query, queryType, targetSummary, carrierInfo, domainWhois, profiles, breaches, timeline, threatVectors, recommendations, networkGraph } = result;

  // Mask Query
  let maskedQuery = query;
  if (queryType === 'email' && options.maskContacts) {
    maskedQuery = maskEmail(query, level);
  } else if (queryType === 'phone' && options.maskContacts) {
    maskedQuery = maskPhone(query, level);
  } else if (queryType === 'username' && options.maskHandles) {
    maskedQuery = maskHandle(query, level);
  } else if (queryType === 'ip' && options.maskNetwork) {
    maskedQuery = maskIp(query, level);
  } else if (options.maskHandles) {
    maskedQuery = maskHandle(query, level);
  }

  // Context for text masking
  const context = {
    fullName: targetSummary.fullNameCandidate,
    query,
    location: targetSummary.locationCandidate || carrierInfo?.location,
  };

  // Target Summary
  const maskedTargetSummary = {
    ...targetSummary,
    primaryAlias: options.maskHandles && targetSummary.primaryAlias ? maskHandle(targetSummary.primaryAlias, level) : targetSummary.primaryAlias,
    fullNameCandidate: options.maskNames && targetSummary.fullNameCandidate ? maskName(targetSummary.fullNameCandidate, level) : targetSummary.fullNameCandidate,
    locationCandidate: options.maskLocations && targetSummary.locationCandidate ? maskLocation(targetSummary.locationCandidate, level) : targetSummary.locationCandidate,
    summaryText: maskText(targetSummary.summaryText, options, context),
  };

  // Carrier Info
  const maskedCarrierInfo: CarrierInfo | undefined = carrierInfo
    ? {
        ...carrierInfo,
        location: options.maskLocations && carrierInfo.location ? maskLocation(carrierInfo.location, level) : carrierInfo.location,
        carrier: options.maskNetwork && carrierInfo.carrier ? (level === 'FULL' ? '[REDACTED_CARRIER]' : carrierInfo.carrier) : carrierInfo.carrier,
      }
    : undefined;

  // Domain Whois
  const maskedDomainWhois: DomainWhois | undefined = domainWhois
    ? {
        ...domainWhois,
        associatedIPs: options.maskNetwork && domainWhois.associatedIPs ? domainWhois.associatedIPs.map((ip) => maskIp(ip, level)) : domainWhois.associatedIPs,
      }
    : undefined;

  // Profiles
  const maskedProfiles: SocialProfile[] = profiles.map((p) => {
    const maskedUsername = options.maskHandles ? maskHandle(p.username, level) : p.username;
    
    // Sanitize Profile URL to prevent handle leakage in link
    let maskedUrl = p.url;
    if (options.maskHandles && p.url && p.username) {
      maskedUrl = p.url.replace(p.username, maskedUsername);
    }

    // Sanitize metadata
    const maskedMetadata: Record<string, string> = {};
    if (p.metadata) {
      Object.entries(p.metadata).forEach(([k, v]) => {
        maskedMetadata[k] = maskText(v, options, context);
      });
    }

    return {
      ...p,
      username: maskedUsername,
      url: maskedUrl,
      metadata: maskedMetadata,
    };
  });

  // Breaches
  const maskedBreaches: BreachRecord[] = breaches.map((b) => ({
    ...b,
    description: maskText(b.description, options, context),
    exposedFields: b.exposedFields.map((f) => {
      // If field specifies sensitive data like 'Full Name', 'Phone Number', 'Email'
      return f;
    }),
  }));

  // Timeline
  const maskedTimeline: TimelineEvent[] = timeline.map((t) => ({
    ...t,
    title: maskText(t.title, options, context),
    description: maskText(t.description, options, context),
  }));

  // Threat Vectors
  const maskedThreatVectors: ThreatVector[] = threatVectors.map((v) => ({
    ...v,
    description: maskText(v.description, options, context),
  }));

  // Recommendations
  const maskedRecommendations = recommendations.map((r) => maskText(r, options, context));

  // Network Graph
  const maskedNodes: NetworkNode[] = networkGraph.nodes.map((node) => {
    let label = node.label;
    if (node.type === 'target') {
      label = maskedQuery;
    } else if (node.type === 'email' && options.maskContacts) {
      label = maskEmail(node.label, level);
    } else if (node.type === 'phone' && options.maskContacts) {
      label = maskPhone(node.label, level);
    } else if (node.type === 'profile' && options.maskHandles) {
      // e.g. "GitHub (johndoe)" -> "GitHub (j*******e)"
      label = node.label.replace(/\(([^)]+)\)/, (_, h) => `(${maskHandle(h, level)})`);
    } else if (node.type === 'ip' && options.maskNetwork) {
      label = maskIp(node.label, level);
    }
    return {
      ...node,
      label,
    };
  });

  return {
    ...result,
    query: maskedQuery,
    targetSummary: maskedTargetSummary,
    carrierInfo: maskedCarrierInfo,
    domainWhois: maskedDomainWhois,
    profiles: maskedProfiles,
    breaches: maskedBreaches,
    timeline: maskedTimeline,
    threatVectors: maskedThreatVectors,
    recommendations: maskedRecommendations,
    networkGraph: {
      nodes: maskedNodes,
      links: networkGraph.links,
    },
  };
}
