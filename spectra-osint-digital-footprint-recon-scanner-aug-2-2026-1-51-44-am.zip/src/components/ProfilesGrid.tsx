import React, { useState } from 'react';
import { ExternalLink, CheckCircle2, AlertCircle, ShieldCheck, Github, Linkedin, Twitter, Globe, MessageSquare, Terminal, Gamepad2, UserCheck, Search } from 'lucide-react';
import { SocialProfile } from '../types';

interface ProfilesGridProps {
  profiles: SocialProfile[];
}

export const ProfilesGrid: React.FC<ProfilesGridProps> = ({ profiles }) => {
  const [selectedCategory, setSelectedCategory] = useState<string>('ALL');
  const [searchQuery, setSearchQuery] = useState<string>('');

  const categories = ['ALL', 'Social', 'Developer', 'Professional', 'Gaming', 'Forum', 'Other'];

  const filteredProfiles = profiles.filter((p) => {
    const matchesCategory = selectedCategory === 'ALL' || p.category === selectedCategory;
    const matchesSearch =
      searchQuery === '' ||
      p.platform.toLowerCase().includes(searchQuery.toLowerCase()) ||
      p.username.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesCategory && matchesSearch;
  });

  const getPlatformIcon = (platform: string) => {
    const p = platform.toLowerCase();
    if (p.includes('github') || p.includes('docker') || p.includes('keybase')) return <Github className="w-5 h-5 text-purple-400" />;
    if (p.includes('linkedin')) return <Linkedin className="w-5 h-5 text-blue-400" />;
    if (p.includes('twitter') || p.includes('x')) return <Twitter className="w-5 h-5 text-sky-400" />;
    if (p.includes('reddit') || p.includes('hackernews') || p.includes('forum')) return <MessageSquare className="w-5 h-5 text-orange-400" />;
    if (p.includes('steam') || p.includes('twitch')) return <Gamepad2 className="w-5 h-5 text-indigo-400" />;
    return <Globe className="w-5 h-5 text-cyan-400" />;
  };

  return (
    <div className="bg-slate-900 rounded-2xl border border-slate-800 p-5 sm:p-6 shadow-xl">
      
      {/* Header & Controls */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-6 pb-4 border-b border-slate-800">
        <div>
          <h3 className="text-xl font-bold font-mono text-slate-100 flex items-center space-x-2">
            <UserCheck className="w-5 h-5 text-cyan-400" />
            <span>Cross-Referenced Profiles & Accounts</span>
            <span className="ml-2 px-2 py-0.5 rounded-full bg-cyan-950 text-cyan-400 border border-cyan-800 text-xs font-mono">
              {profiles.length} Matched
            </span>
          </h3>
          <p className="text-xs text-slate-400 font-mono mt-0.5">
            Surfaced account footprints, username handles, and associated profile metadata across web platforms.
          </p>
        </div>

        {/* Search input for profiles */}
        <div className="relative min-w-[220px]">
          <Search className="w-4 h-4 text-slate-500 absolute left-3 top-1/2 -translate-y-1/2 pointer-events-none" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Filter platforms or handles..."
            className="w-full pl-9 pr-3 py-1.5 bg-slate-950 border border-slate-800 rounded-xl text-slate-200 text-xs font-mono focus:border-cyan-500 focus:outline-none"
          />
        </div>
      </div>

      {/* Category Tabs */}
      <div className="flex flex-wrap items-center gap-1.5 mb-6 text-xs font-mono">
        {categories.map((cat) => (
          <button
            key={cat}
            onClick={() => setSelectedCategory(cat)}
            className={`px-3 py-1.5 rounded-lg font-medium transition ${
              selectedCategory === cat
                ? 'bg-cyan-600 text-white shadow-sm shadow-cyan-600/30'
                : 'bg-slate-950 text-slate-400 hover:text-slate-200 hover:bg-slate-800 border border-slate-800'
            }`}
          >
            {cat}
          </button>
        ))}
      </div>

      {/* Profiles Cards Grid */}
      {filteredProfiles.length === 0 ? (
        <div className="text-center py-12 bg-slate-950 rounded-xl border border-slate-800/80 text-slate-500 font-mono text-xs">
          No matching profiles found for category filter "{selectedCategory}".
        </div>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {filteredProfiles.map((p) => (
            <div
              key={p.id}
              className="bg-slate-950 rounded-xl border border-slate-800 hover:border-slate-700 p-4 transition-all duration-200 hover:shadow-lg hover:shadow-cyan-950/20 flex flex-col justify-between group"
            >
              <div>
                
                {/* Top Platform & Status */}
                <div className="flex items-center justify-between mb-2">
                  <div className="flex items-center space-x-2.5">
                    <div className="p-2 rounded-lg bg-slate-900 border border-slate-800 group-hover:border-slate-700 transition">
                      {getPlatformIcon(p.platform)}
                    </div>
                    <div>
                      <h4 className="font-mono font-bold text-slate-100 text-sm group-hover:text-cyan-300 transition">
                        {p.platform}
                      </h4>
                      <span className="text-[10px] font-mono text-slate-500 uppercase">{p.category}</span>
                    </div>
                  </div>

                  <span
                    className={`px-2 py-0.5 rounded text-[10px] font-mono font-bold flex items-center space-x-1 ${
                      p.status === 'VERIFIED'
                        ? 'bg-emerald-950 text-emerald-400 border border-emerald-800'
                        : p.status === 'FOUND'
                        ? 'bg-cyan-950 text-cyan-400 border border-cyan-800'
                        : 'bg-slate-800 text-slate-400'
                    }`}
                  >
                    {p.status === 'VERIFIED' ? <CheckCircle2 className="w-3 h-3" /> : null}
                    <span>{p.status}</span>
                  </span>
                </div>

                {/* Username handle & Direct URL */}
                <div className="mb-3 pt-2 border-t border-slate-900">
                  <span className="text-xs font-mono font-semibold text-slate-200 block truncate">
                    @{p.username}
                  </span>
                  <a
                    href={p.url}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="text-[11px] font-mono text-cyan-400 hover:text-cyan-300 underline block truncate mt-0.5"
                  >
                    {p.url}
                  </a>
                  {p.accountAge && (
                    <span className="text-[10px] font-mono text-slate-400 block mt-1">
                      Account Est: {p.accountAge}
                    </span>
                  )}
                </div>

                {/* Metadata Tags */}
                {p.metadata && Object.keys(p.metadata).length > 0 && (
                  <div className="space-y-1 mb-3 text-[11px] font-mono bg-slate-900/80 p-2.5 rounded-lg border border-slate-800/80">
                    {Object.entries(p.metadata).map(([k, v]) => (
                      <div key={k} className="flex items-center justify-between text-slate-400">
                        <span className="text-slate-500">{k}:</span>
                        <span className="text-slate-200 font-medium truncate max-w-[140px]">{v}</span>
                      </div>
                    ))}
                  </div>
                )}

              </div>

              {/* Confidence Meter & External Link */}
              <div className="pt-3 border-t border-slate-900 flex items-center justify-between text-xs font-mono">
                
                <div className="flex items-center space-x-2">
                  <span className="text-[10px] text-slate-500">Confidence:</span>
                  <div className="w-16 h-1.5 bg-slate-800 rounded-full overflow-hidden">
                    <div
                      className="h-full bg-gradient-to-r from-cyan-500 to-blue-500 rounded-full"
                      style={{ width: `${p.confidence}%` }}
                    ></div>
                  </div>
                  <span className="text-[10px] font-bold text-cyan-400">{p.confidence}%</span>
                </div>

                <a
                  href={p.url}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="px-2.5 py-1 rounded bg-slate-900 hover:bg-slate-800 border border-slate-800 hover:border-cyan-500/50 text-cyan-400 font-medium flex items-center space-x-1 transition text-xs"
                >
                  <span>Visit</span>
                  <ExternalLink className="w-3 h-3" />
                </a>

              </div>

            </div>
          ))}
        </div>
      )}

    </div>
  );
};
