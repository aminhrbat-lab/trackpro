import React from 'react';
import { Clock, ShieldAlert, UserPlus, Globe, AlertCircle } from 'lucide-react';
import { TimelineEvent } from '../types';

interface TimelineViewProps {
  timeline: TimelineEvent[];
}

export const TimelineView: React.FC<TimelineViewProps> = ({ timeline }) => {
  const getCategoryIcon = (category: TimelineEvent['category']) => {
    switch (category) {
      case 'Data Breach': return <ShieldAlert className="w-4 h-4 text-red-400" />;
      case 'Domain Register': return <Globe className="w-4 h-4 text-indigo-400" />;
      case 'Security Alert': return <AlertCircle className="w-4 h-4 text-amber-400" />;
      default: return <UserPlus className="w-4 h-4 text-cyan-400" />;
    }
  };

  return (
    <div className="bg-slate-900 rounded-2xl border border-slate-800 p-5 sm:p-6 shadow-xl">
      
      {/* Header */}
      <div className="mb-6 pb-4 border-b border-slate-800">
        <h3 className="text-xl font-bold font-mono text-slate-100 flex items-center space-x-2">
          <Clock className="w-5 h-5 text-cyan-400" />
          <span>Footprint Discovery Timeline</span>
        </h3>
        <p className="text-xs text-slate-400 font-mono mt-0.5">
          Chronological sequence of online account creations, leak exposures, and domain activity.
        </p>
      </div>

      {/* Timeline List */}
      <div className="relative pl-6 space-y-6 before:absolute before:left-2.5 before:top-2 before:bottom-2 before:w-0.5 before:bg-slate-800 font-mono">
        {timeline.map((item) => (
          <div key={item.id} className="relative group">
            
            {/* Timeline Dot */}
            <div
              className={`absolute -left-6 top-1 w-5 h-5 rounded-full border-2 bg-slate-900 flex items-center justify-center shrink-0 ${
                item.severity === 'danger'
                  ? 'border-red-500 text-red-400'
                  : item.severity === 'warning'
                  ? 'border-amber-500 text-amber-400'
                  : 'border-cyan-500 text-cyan-400'
              }`}
            >
              {getCategoryIcon(item.category)}
            </div>

            {/* Event Content Box */}
            <div className="bg-slate-950 p-4 rounded-xl border border-slate-800 group-hover:border-slate-700 transition">
              <div className="flex flex-wrap items-center justify-between gap-2 mb-1">
                <span className="font-bold text-slate-100 text-sm">{item.title}</span>
                <span className="text-xs text-slate-400 bg-slate-900 px-2 py-0.5 rounded border border-slate-800">
                  {item.date}
                </span>
              </div>

              <p className="text-xs text-slate-300 leading-relaxed mb-2">{item.description}</p>

              <div className="flex items-center justify-between text-[11px] text-slate-500">
                <span>Category: <strong className="text-slate-400">{item.category}</strong></span>
                <span>Source: <strong className="text-cyan-400">{item.source}</strong></span>
              </div>
            </div>

          </div>
        ))}
      </div>

    </div>
  );
};
