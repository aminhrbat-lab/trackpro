import React, { useState } from 'react';
import { ShieldAlert, Database, AlertTriangle, Key, Search, FileCode, CheckCircle2, ChevronRight, Lock } from 'lucide-react';
import { BreachRecord, RiskLevel } from '../types';

interface BreachRecordsTableProps {
  breaches: BreachRecord[];
}

export const BreachRecordsTable: React.FC<BreachRecordsTableProps> = ({ breaches }) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedSeverity, setSelectedSeverity] = useState<string>('ALL');
  const [expandedId, setExpandedId] = useState<string | null>(null);

  const filteredBreaches = breaches.filter((b) => {
    const matchesSev = selectedSeverity === 'ALL' || b.severity === selectedSeverity;
    const matchesSearch =
      searchQuery === '' ||
      b.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      b.domain.toLowerCase().includes(searchQuery.toLowerCase()) ||
      b.exposedFields.some((f) => f.toLowerCase().includes(searchQuery.toLowerCase()));
    return matchesSev && matchesSearch;
  });

  const getSeverityBadge = (sev: RiskLevel) => {
    switch (sev) {
      case 'CRITICAL':
        return 'bg-red-950 text-red-400 border-red-800';
      case 'HIGH':
        return 'bg-orange-950 text-orange-400 border-orange-800';
      case 'MEDIUM':
        return 'bg-amber-950 text-amber-400 border-amber-800';
      default:
        return 'bg-emerald-950 text-emerald-400 border-emerald-800';
    }
  };

  return (
    <div className="bg-slate-900 rounded-2xl border border-slate-800 p-5 sm:p-6 shadow-xl">
      
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-6 pb-4 border-b border-slate-800">
        <div>
          <h3 className="text-xl font-bold font-mono text-slate-100 flex items-center space-x-2">
            <ShieldAlert className="w-5 h-5 text-red-400" />
            <span>Compromised Data Breaches & Leaks</span>
            <span className="ml-2 px-2 py-0.5 rounded-full bg-red-950 text-red-400 border border-red-800 text-xs font-mono">
              {breaches.length} Exposures
            </span>
          </h3>
          <p className="text-xs text-slate-400 font-mono mt-0.5">
            Cross-indexed darknet dumps, mega compilation leaks, and public API scraping incidents.
          </p>
        </div>

        {/* Filter Controls */}
        <div className="flex flex-wrap items-center gap-2">
          <div className="relative min-w-[180px]">
            <Search className="w-4 h-4 text-slate-500 absolute left-3 top-1/2 -translate-y-1/2 pointer-events-none" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Filter breaches or fields..."
              className="w-full pl-9 pr-3 py-1.5 bg-slate-950 border border-slate-800 rounded-xl text-slate-200 text-xs font-mono focus:border-cyan-500 focus:outline-none"
            />
          </div>

          <div className="flex items-center space-x-1 text-xs font-mono">
            {['ALL', 'CRITICAL', 'HIGH', 'MEDIUM'].map((s) => (
              <button
                key={s}
                onClick={() => setSelectedSeverity(s)}
                className={`px-2.5 py-1.5 rounded-lg font-medium transition ${
                  selectedSeverity === s
                    ? 'bg-slate-800 text-cyan-400 border border-cyan-800'
                    : 'bg-slate-950 text-slate-500 border border-slate-800 hover:text-slate-300'
                }`}
              >
                {s}
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Breaches Table */}
      {filteredBreaches.length === 0 ? (
        <div className="text-center py-12 bg-slate-950 rounded-xl border border-slate-800/80 text-emerald-400 font-mono text-xs flex flex-col items-center justify-center space-y-2">
          <CheckCircle2 className="w-8 h-8 text-emerald-400" />
          <span>No breach exposure records matched the filter criteria.</span>
        </div>
      ) : (
        <div className="space-y-3">
          {filteredBreaches.map((b) => {
            const isExpanded = expandedId === b.id;

            return (
              <div
                key={b.id}
                className="bg-slate-950 rounded-xl border border-slate-800 hover:border-slate-700 transition overflow-hidden"
              >
                {/* Row Summary */}
                <div
                  onClick={() => setExpandedId(isExpanded ? null : b.id)}
                  className="p-4 cursor-pointer flex flex-col sm:flex-row sm:items-center justify-between gap-3 hover:bg-slate-900/50 transition"
                >
                  <div className="flex items-start space-x-3">
                    <div className="p-2.5 rounded-xl bg-slate-900 border border-slate-800 shrink-0 text-red-400">
                      <Database className="w-5 h-5" />
                    </div>

                    <div>
                      <div className="flex flex-wrap items-center gap-2 mb-1">
                        <h4 className="font-mono font-bold text-slate-100 text-sm">{b.title}</h4>
                        <span className={`px-2 py-0.5 rounded text-[10px] font-mono font-bold border ${getSeverityBadge(b.severity)}`}>
                          {b.severity} SEVERITY
                        </span>
                      </div>

                      <div className="flex flex-wrap items-center gap-x-4 gap-y-1 text-xs font-mono text-slate-400">
                        <span>Breach Date: <strong className="text-slate-200">{b.breachDate}</strong></span>
                        <span>Source: <strong className="text-slate-300">{b.domain}</strong></span>
                        {b.pwnCount > 0 && (
                          <span>Exposed Accounts: <strong className="text-cyan-400">{b.pwnCount.toLocaleString()}</strong></span>
                        )}
                      </div>
                    </div>
                  </div>

                  <div className="flex items-center space-x-3 self-end sm:self-center">
                    <div className="flex flex-wrap gap-1 max-w-xs justify-end">
                      {b.exposedFields.slice(0, 3).map((f, i) => (
                        <span key={i} className="px-2 py-0.5 rounded bg-slate-900 border border-slate-800 text-[10px] font-mono text-slate-300">
                          {f}
                        </span>
                      ))}
                      {b.exposedFields.length > 3 && (
                        <span className="px-1.5 py-0.5 text-[10px] font-mono text-slate-500">+{b.exposedFields.length - 3}</span>
                      )}
                    </div>

                    <ChevronRight className={`w-5 h-5 text-slate-500 transition-transform ${isExpanded ? 'rotate-90' : ''}`} />
                  </div>
                </div>

                {/* Expanded Drawer Details */}
                {isExpanded && (
                  <div className="p-4 bg-slate-900/90 border-t border-slate-800 text-xs font-mono space-y-3">
                    <p className="text-slate-300 leading-relaxed">{b.description}</p>

                    <div>
                      <span className="text-slate-400 font-bold block mb-1.5">Full Compromised Data Fields:</span>
                      <div className="flex flex-wrap gap-1.5">
                        {b.exposedFields.map((field, idx) => (
                          <span
                            key={idx}
                            className={`px-2.5 py-1 rounded-lg border font-semibold flex items-center space-x-1 ${
                              field.toLowerCase().includes('password')
                                ? 'bg-red-950/80 text-red-300 border-red-800'
                                : 'bg-slate-950 text-slate-300 border-slate-800'
                            }`}
                          >
                            {field.toLowerCase().includes('password') && <Lock className="w-3 h-3 text-red-400" />}
                            <span>{field}</span>
                          </span>
                        ))}
                      </div>
                    </div>

                    <div className="p-3 bg-slate-950 rounded-lg border border-slate-800/80 text-[11px] text-amber-300 flex items-start space-x-2">
                      <AlertTriangle className="w-4 h-4 shrink-0 text-amber-400 mt-0.5" />
                      <span>
                        Remediation Advisory: If the subject reuses passwords across other platforms, rotate those credentials immediately and force logouts.
                      </span>
                    </div>

                  </div>
                )}

              </div>
            );
          })}
        </div>
      )}

    </div>
  );
};
