import React, { useState } from 'react';
import { Network, ZoomIn, ZoomOut, RotateCcw, ShieldAlert, Globe, UserCheck, AlertCircle, Info } from 'lucide-react';
import { OsintResult, NetworkNode } from '../types';

interface FootprintGraphProps {
  result: OsintResult;
  onSelectNodeFilter?: (nodeLabel: string) => void;
}

export const FootprintGraph: React.FC<FootprintGraphProps> = ({ result, onSelectNodeFilter }) => {
  const [activeNode, setActiveNode] = useState<NetworkNode | null>(null);
  const [zoomLevel, setZoomLevel] = useState(1);

  const { nodes, links } = result.networkGraph;

  // Center position
  const width = 800;
  const height = 400;
  const cx = width / 2;
  const cy = height / 2;

  // Layout calculations: place central target at center, other nodes around in concentric radial rings
  const positionedNodes = nodes.map((node, index) => {
    if (node.type === 'target') {
      return { ...node, x: cx, y: cy };
    }
    const angle = ((index - 1) / (nodes.length - 1)) * 2 * Math.PI - Math.PI / 2;
    const radius = node.type === 'breach' ? 140 : 120;
    return {
      ...node,
      x: cx + radius * Math.cos(angle),
      y: cy + radius * Math.sin(angle),
    };
  });

  const getNodeColor = (node: NetworkNode) => {
    if (node.type === 'target') return { fill: '#0284c7', stroke: '#38bdf8' }; // Cyan
    if (node.type === 'breach') return { fill: '#dc2626', stroke: '#f87171' }; // Red
    if (node.type === 'domain') return { fill: '#4f46e5', stroke: '#818cf8' }; // Indigo
    if (node.type === 'ip') return { fill: '#9333ea', stroke: '#c084fc' }; // Purple
    return { fill: '#10b981', stroke: '#34d399' }; // Emerald profile
  };

  return (
    <div className="bg-slate-900 rounded-2xl border border-slate-800 p-5 shadow-xl">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 mb-4 pb-3 border-b border-slate-800">
        <div>
          <h3 className="text-lg font-bold font-mono text-slate-100 flex items-center space-x-2">
            <Network className="w-5 h-5 text-cyan-400" />
            <span>Identity Linkage & Footprint Network</span>
          </h3>
          <p className="text-xs text-slate-400 font-mono">
            Interactive map connecting target entity to discovered profiles, leak databases, registered domains, and network nodes.
          </p>
        </div>

        {/* Graph Controls */}
        <div className="flex items-center space-x-2 font-mono text-xs">
          <button
            onClick={() => setZoomLevel((z) => Math.min(1.5, z + 0.1))}
            className="p-1.5 rounded bg-slate-800 hover:bg-slate-700 text-slate-300 border border-slate-700"
            title="Zoom In"
          >
            <ZoomIn className="w-4 h-4" />
          </button>
          <button
            onClick={() => setZoomLevel((z) => Math.max(0.7, z - 0.1))}
            className="p-1.5 rounded bg-slate-800 hover:bg-slate-700 text-slate-300 border border-slate-700"
            title="Zoom Out"
          >
            <ZoomOut className="w-4 h-4" />
          </button>
          <button
            onClick={() => setZoomLevel(1)}
            className="p-1.5 rounded bg-slate-800 hover:bg-slate-700 text-slate-300 border border-slate-700"
            title="Reset View"
          >
            <RotateCcw className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* SVG Canvas Box */}
      <div className="relative bg-slate-950 rounded-xl border border-slate-800/80 overflow-hidden min-h-[360px] flex items-center justify-center">
        
        {/* Radar concentric ring grid effect */}
        <div className="absolute inset-0 flex items-center justify-center pointer-events-none opacity-20">
          <div className="w-64 h-64 rounded-full border border-cyan-500"></div>
          <div className="w-96 h-96 rounded-full border border-cyan-500 absolute"></div>
        </div>

        <svg
          viewBox={`0 0 ${width} ${height}`}
          className="w-full h-auto max-h-[420px] transition-transform duration-200"
          style={{ transform: `scale(${zoomLevel})` }}
        >
          {/* Render Link Lines */}
          {links.map((link, idx) => {
            const sourceNode = positionedNodes.find((n) => n.id === link.source) || positionedNodes[0];
            const targetNode = positionedNodes.find((n) => n.id === link.target) || positionedNodes[1];

            if (!sourceNode || !targetNode) return null;

            const isHighlighted =
              activeNode && (activeNode.id === sourceNode.id || activeNode.id === targetNode.id);

            return (
              <g key={idx}>
                <line
                  x1={sourceNode.x}
                  y1={sourceNode.y}
                  x2={targetNode.x}
                  y2={targetNode.y}
                  stroke={isHighlighted ? '#38bdf8' : '#334155'}
                  strokeWidth={isHighlighted ? 2.5 : 1.2}
                  strokeDasharray={sourceNode.type === 'breach' || targetNode.type === 'breach' ? '4 4' : undefined}
                />
              </g>
            );
          })}

          {/* Render Nodes */}
          {positionedNodes.map((node) => {
            const color = getNodeColor(node);
            const isSelected = activeNode?.id === node.id;
            const radius = node.type === 'target' ? 24 : 16;

            return (
              <g
                key={node.id}
                className="cursor-pointer group"
                onClick={() => {
                  setActiveNode(node);
                  if (onSelectNodeFilter) onSelectNodeFilter(node.label);
                }}
                onMouseEnter={() => setActiveNode(node)}
              >
                {/* Pulse Ring if selected or central target */}
                {(isSelected || node.type === 'target') && (
                  <circle
                    cx={node.x}
                    cy={node.y}
                    r={radius + 8}
                    fill="none"
                    stroke={color.stroke}
                    strokeWidth="1.5"
                    className="animate-ping opacity-50"
                  />
                )}

                {/* Main Node Circle */}
                <circle
                  cx={node.x}
                  cy={node.y}
                  r={radius}
                  fill={color.fill}
                  stroke={color.stroke}
                  strokeWidth="2"
                  className="transition-transform duration-150 group-hover:scale-110"
                />

                {/* Node Label Text */}
                <text
                  x={node.x}
                  y={node.y + radius + 14}
                  textAnchor="middle"
                  fill="#f1f5f9"
                  fontSize={node.type === 'target' ? '12 font-bold font-mono' : '10 font-mono'}
                  className="pointer-events-none drop-shadow"
                >
                  {node.label.length > 20 ? `${node.label.slice(0, 18)}...` : node.label}
                </text>
              </g>
            );
          })}
        </svg>

        {/* Floating Node Information Overlay */}
        {activeNode && (
          <div className="absolute bottom-3 left-3 right-3 bg-slate-900/95 border border-slate-700 rounded-xl p-3 backdrop-blur-md font-mono text-xs flex items-center justify-between shadow-xl">
            <div className="flex items-center space-x-3">
              <span className="w-3 h-3 rounded-full bg-cyan-400"></span>
              <div>
                <span className="font-bold text-slate-100 block">{activeNode.label}</span>
                <span className="text-slate-400 text-[10px] uppercase">
                  Node Type: <strong className="text-cyan-300">{activeNode.type}</strong>
                </span>
              </div>
            </div>
            <span className="text-slate-400 text-[10px]">Click node to inspect details below</span>
          </div>
        )}

      </div>

      {/* Legend Footer */}
      <div className="mt-3 flex flex-wrap items-center justify-center gap-4 text-xs font-mono text-slate-400">
        <span className="flex items-center space-x-1.5">
          <span className="w-3 h-3 rounded-full bg-cyan-600 border border-cyan-400"></span>
          <span>Target Query</span>
        </span>
        <span className="flex items-center space-x-1.5">
          <span className="w-3 h-3 rounded-full bg-emerald-600 border border-emerald-400"></span>
          <span>Social / Web Account</span>
        </span>
        <span className="flex items-center space-x-1.5">
          <span className="w-3 h-3 rounded-full bg-red-600 border border-red-400"></span>
          <span>Compromised Breach Data</span>
        </span>
        <span className="flex items-center space-x-1.5">
          <span className="w-3 h-3 rounded-full bg-indigo-600 border border-indigo-400"></span>
          <span>Domain / IP Node</span>
        </span>
      </div>

    </div>
  );
};
