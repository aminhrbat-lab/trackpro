import React, { useState } from 'react';
import { Terminal, Copy, Check, Code, ShieldCheck } from 'lucide-react';
import { OsintResult } from '../types';

interface RawDataDrawerProps {
  result: OsintResult;
}

export const RawDataDrawer: React.FC<RawDataDrawerProps> = ({ result }) => {
  const [copied, setCopied] = useState(false);
  const [showFullJson, setShowFullJson] = useState(false);

  const jsonString = JSON.stringify(result, null, 2);

  const handleCopy = () => {
    navigator.clipboard.writeText(jsonString);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="bg-slate-900 rounded-2xl border border-slate-800 p-5 sm:p-6 shadow-xl font-mono">
      
      {/* Header */}
      <div className="flex items-center justify-between mb-4 pb-3 border-b border-slate-800">
        <div>
          <h3 className="text-lg font-bold text-slate-100 flex items-center space-x-2">
            <Terminal className="w-5 h-5 text-cyan-400" />
            <span>Technical OSINT Payload & Raw Inspector</span>
          </h3>
          <p className="text-xs text-slate-400 mt-0.5">
            Cryptographic audit payload timestamped {result.timestamp}
          </p>
        </div>

        <div className="flex items-center space-x-2">
          <button
            onClick={() => setShowFullJson(!showFullJson)}
            className="px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 border border-slate-700 text-xs flex items-center space-x-1.5 transition"
          >
            <Code className="w-3.5 h-3.5 text-cyan-400" />
            <span>{showFullJson ? 'Collapse JSON' : 'Expand Full JSON'}</span>
          </button>

          <button
            onClick={handleCopy}
            className="px-3 py-1.5 rounded-lg bg-cyan-600 hover:bg-cyan-500 text-white font-medium text-xs flex items-center space-x-1.5 transition shadow-sm"
          >
            {copied ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
            <span>{copied ? 'Copied' : 'Copy JSON'}</span>
          </button>
        </div>
      </div>

      {/* Code Block */}
      <div className="bg-slate-950 rounded-xl p-4 border border-slate-800/90 overflow-x-auto text-xs text-cyan-300 font-mono max-h-96">
        <pre className={showFullJson ? 'whitespace-pre-wrap' : 'line-clamp-12'}>
          {jsonString}
        </pre>
      </div>

    </div>
  );
};
