import React from 'react';
import { X, Scale, ShieldCheck, Lock, AlertTriangle, FileText } from 'lucide-react';

interface ComplianceModalProps {
  onClose: () => void;
}

export const ComplianceModal: React.FC<ComplianceModalProps> = ({ onClose }) => {
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-sm animate-fade-in">
      <div className="bg-slate-900 border border-slate-800 rounded-2xl max-w-2xl w-full p-6 shadow-2xl font-mono space-y-5 text-xs text-slate-300">
        
        {/* Header */}
        <div className="flex items-center justify-between border-b border-slate-800 pb-4">
          <div className="flex items-center space-x-2.5">
            <div className="p-2 rounded-lg bg-amber-950 text-amber-400 border border-amber-800">
              <Scale className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-bold text-slate-100 text-base">Ethical OSINT & Policy Notice</h3>
              <p className="text-slate-400 text-[11px]">Authorized Security Research & Legal Compliance Framework</p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-400 hover:text-slate-200 transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Sections */}
        <div className="space-y-4 max-h-[60vh] overflow-y-auto pr-1">
          
          <div className="p-3 bg-slate-950 rounded-xl border border-slate-800 space-y-1">
            <h4 className="font-bold text-slate-100 flex items-center space-x-2">
              <ShieldCheck className="w-4 h-4 text-emerald-400" />
              <span>1. Authorized Purpose & Ethical Conduct</span>
            </h4>
            <p className="text-slate-400 leading-relaxed">
              Spectra OSINT aggregates publicly available open-source intelligence (OSINT), darknet breach indexes, and WHOIS records solely for authorized threat assessments, identity defense, digital self-audits, and defensive security research.
            </p>
          </div>

          <div className="p-3 bg-slate-950 rounded-xl border border-slate-800 space-y-1">
            <h4 className="font-bold text-slate-100 flex items-center space-x-2">
              <Lock className="w-4 h-4 text-cyan-400" />
              <span>2. No Stalking or Unlawful Harassment</span>
            </h4>
            <p className="text-slate-400 leading-relaxed">
              Users are strictly prohibited from using this engine for doxxing, cyberstalking, harassment, unlawful extortion, or unauthorized identity theft. All scans log non-retained cryptographic search hashes.
            </p>
          </div>

          <div className="p-3 bg-slate-950 rounded-xl border border-slate-800 space-y-1">
            <h4 className="font-bold text-slate-100 flex items-center space-x-2">
              <AlertTriangle className="w-4 h-4 text-amber-400" />
              <span>3. Data Privacy Rights (GDPR / CCPA)</span>
            </h4>
            <p className="text-slate-400 leading-relaxed">
              This platform does not host original user credentials. All breach queries cross-reference public indexed databases. If you wish to remove or opt-out your data from public indexers, please refer to the platform opt-out links in our mitigation guide.
            </p>
          </div>

        </div>

        {/* Footer */}
        <div className="pt-3 border-t border-slate-800 flex justify-end">
          <button
            onClick={onClose}
            className="px-5 py-2 bg-cyan-600 hover:bg-cyan-500 text-white font-bold rounded-xl transition shadow-sm"
          >
            I Acknowledge & Accept
          </button>
        </div>

      </div>
    </div>
  );
};
