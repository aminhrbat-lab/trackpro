import React, { useState } from 'react';
import { Eye, EyeOff, Shield, ShieldCheck, ShieldAlert, Sliders, ChevronDown, ChevronUp, Lock, CheckCircle2, AlertCircle, Info } from 'lucide-react';
import { AnonymizationLevel, AnonymizationOptions } from '../types';

interface AnonymizationControlBarProps {
  options: AnonymizationOptions;
  onChangeOptions: (newOptions: AnonymizationOptions) => void;
  compact?: boolean;
}

export const AnonymizationControlBar: React.FC<AnonymizationControlBarProps> = ({
  options,
  onChangeOptions,
  compact = false,
}) => {
  const [showDetails, setShowDetails] = useState(false);

  const handleLevelChange = (level: AnonymizationLevel) => {
    if (level === 'OFF') {
      onChangeOptions({
        ...options,
        level: 'OFF',
      });
    } else if (level === 'PARTIAL') {
      onChangeOptions({
        level: 'PARTIAL',
        maskNames: true,
        maskLocations: true,
        maskContacts: true,
        maskHandles: true,
        maskNetwork: true,
      });
    } else {
      onChangeOptions({
        level: 'FULL',
        maskNames: true,
        maskLocations: true,
        maskContacts: true,
        maskHandles: true,
        maskNetwork: true,
      });
    }
  };

  const handleToggleCategory = (key: keyof Omit<AnonymizationOptions, 'level'>) => {
    const updated = { ...options, [key]: !options[key] };
    // If all toggles are turned off, auto level = OFF, else if level was OFF turn to PARTIAL
    const hasAnyActive = updated.maskNames || updated.maskLocations || updated.maskContacts || updated.maskHandles || updated.maskNetwork;
    if (!hasAnyActive) {
      updated.level = 'OFF';
    } else if (updated.level === 'OFF') {
      updated.level = 'PARTIAL';
    }
    onChangeOptions(updated);
  };

  const getLevelBadge = (level: AnonymizationLevel) => {
    switch (level) {
      case 'FULL':
        return {
          bg: 'bg-purple-950/90 text-purple-300 border-purple-800',
          label: 'FULL PSEUDONYMIZED',
          icon: <Lock className="w-3.5 h-3.5 text-purple-400" />,
        };
      case 'PARTIAL':
        return {
          bg: 'bg-cyan-950/90 text-cyan-300 border-cyan-800',
          label: 'PARTIAL MASKED',
          icon: <ShieldCheck className="w-3.5 h-3.5 text-cyan-400" />,
        };
      default:
        return {
          bg: 'bg-amber-950/90 text-amber-300 border-amber-800',
          label: 'UNMASKED (RAW DATA)',
          icon: <Eye className="w-3.5 h-3.5 text-amber-400" />,
        };
    }
  };

  const currentBadge = getLevelBadge(options.level);

  if (compact) {
    return (
      <div className="flex items-center space-x-2 font-mono text-xs">
        <div className={`px-2.5 py-1 rounded-lg border font-bold flex items-center space-x-1.5 ${currentBadge.bg}`}>
          {currentBadge.icon}
          <span>{currentBadge.label}</span>
        </div>

        <button
          onClick={() => handleLevelChange(options.level === 'OFF' ? 'PARTIAL' : options.level === 'PARTIAL' ? 'FULL' : 'OFF')}
          className="p-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 border border-slate-700 transition"
          title="Cycle Anonymization Level"
        >
          <EyeOff className="w-4 h-4 text-cyan-400" />
        </button>
      </div>
    );
  }

  return (
    <div className="bg-slate-900 border border-slate-800 rounded-2xl p-4 sm:p-5 shadow-xl font-mono relative overflow-hidden transition-all">
      {/* Background Cyber Privacy Glow */}
      <div className="absolute -top-10 -right-10 w-48 h-48 bg-cyan-500/5 rounded-full blur-2xl pointer-events-none"></div>

      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 relative z-10">
        
        {/* Left: Indicator & Description */}
        <div className="flex items-start space-x-3">
          <div className="p-2.5 rounded-xl bg-slate-950 border border-slate-800 shrink-0">
            {options.level === 'OFF' ? (
              <Eye className="w-6 h-6 text-amber-400" />
            ) : options.level === 'FULL' ? (
              <Lock className="w-6 h-6 text-purple-400 animate-pulse" />
            ) : (
              <ShieldCheck className="w-6 h-6 text-cyan-400" />
            )}
          </div>

          <div>
            <div className="flex flex-wrap items-center gap-2">
              <h4 className="font-bold text-slate-100 text-sm sm:text-base flex items-center space-x-2">
                <span>Real-Time Privacy & Anonymization Engine</span>
              </h4>
              <span className={`px-2 py-0.5 rounded text-[10px] font-bold border flex items-center space-x-1 ${currentBadge.bg}`}>
                {currentBadge.icon}
                <span>{currentBadge.label}</span>
              </span>
            </div>
            <p className="text-xs text-slate-400 mt-0.5 max-w-xl leading-relaxed">
              Automatically masks sensitive personal identifiers (PII), candidate names, street addresses, precise locations, phone numbers, and handles across screen displays, raw drawers, and exports.
            </p>
          </div>
        </div>

        {/* Right: Level Switcher Buttons */}
        <div className="flex flex-wrap items-center gap-2 shrink-0">
          
          <button
            onClick={() => handleLevelChange('OFF')}
            className={`px-3 py-1.5 rounded-xl border text-xs font-bold transition flex items-center space-x-1.5 ${
              options.level === 'OFF'
                ? 'bg-amber-950 text-amber-300 border-amber-800 shadow-sm shadow-amber-950/50'
                : 'bg-slate-950 text-slate-400 border-slate-800 hover:text-slate-200 hover:bg-slate-800'
            }`}
          >
            <Eye className="w-3.5 h-3.5" />
            <span>Off (Raw)</span>
          </button>

          <button
            onClick={() => handleLevelChange('PARTIAL')}
            className={`px-3 py-1.5 rounded-xl border text-xs font-bold transition flex items-center space-x-1.5 ${
              options.level === 'PARTIAL'
                ? 'bg-cyan-600 text-white border-cyan-500 shadow-md shadow-cyan-600/30'
                : 'bg-slate-950 text-slate-400 border-slate-800 hover:text-slate-200 hover:bg-slate-800'
            }`}
          >
            <ShieldCheck className="w-3.5 h-3.5" />
            <span>Partial (Masked)</span>
          </button>

          <button
            onClick={() => handleLevelChange('FULL')}
            className={`px-3 py-1.5 rounded-xl border text-xs font-bold transition flex items-center space-x-1.5 ${
              options.level === 'FULL'
                ? 'bg-purple-600 text-white border-purple-500 shadow-md shadow-purple-600/30'
                : 'bg-slate-950 text-slate-400 border-slate-800 hover:text-slate-200 hover:bg-slate-800'
            }`}
          >
            <Lock className="w-3.5 h-3.5" />
            <span>Full (Redacted)</span>
          </button>

          <button
            onClick={() => setShowDetails(!showDetails)}
            className="p-2 rounded-xl bg-slate-950 text-slate-400 hover:text-slate-200 border border-slate-800 transition flex items-center space-x-1"
            title="Configure Masking Toggles"
          >
            <Sliders className="w-4 h-4 text-cyan-400" />
            {showDetails ? <ChevronUp className="w-3.5 h-3.5" /> : <ChevronDown className="w-3.5 h-3.5" />}
          </button>

        </div>

      </div>

      {/* Expanded Granular Toggles Drawer */}
      {showDetails && (
        <div className="mt-4 pt-4 border-t border-slate-800/80 animate-fade-in text-xs space-y-3">
          <div className="flex items-center justify-between text-slate-400 text-[11px] uppercase font-bold">
            <span>Granular PII Masking Rules</span>
            <span className="text-cyan-400">Custom Category Filters</span>
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-2">
            
            {/* Toggle 1: Full Names */}
            <button
              onClick={() => handleToggleCategory('maskNames')}
              className={`p-2.5 rounded-xl border text-left transition flex items-center justify-between ${
                options.maskNames
                  ? 'bg-cyan-950/60 border-cyan-800 text-cyan-300'
                  : 'bg-slate-950 border-slate-800 text-slate-500 hover:text-slate-400'
              }`}
            >
              <div>
                <span className="font-bold block text-xs">Full Names</span>
                <span className="text-[10px] opacity-70 block">Candidate Person Names</span>
              </div>
              <input
                type="checkbox"
                checked={options.maskNames}
                onChange={() => {}}
                className="rounded bg-slate-900 border-slate-700 text-cyan-500 focus:ring-0"
              />
            </button>

            {/* Toggle 2: Addresses & Locations */}
            <button
              onClick={() => handleToggleCategory('maskLocations')}
              className={`p-2.5 rounded-xl border text-left transition flex items-center justify-between ${
                options.maskLocations
                  ? 'bg-cyan-950/60 border-cyan-800 text-cyan-300'
                  : 'bg-slate-950 border-slate-800 text-slate-500 hover:text-slate-400'
              }`}
            >
              <div>
                <span className="font-bold block text-xs">Locations & Address</span>
                <span className="text-[10px] opacity-70 block">City, Region & Carrier</span>
              </div>
              <input
                type="checkbox"
                checked={options.maskLocations}
                onChange={() => {}}
                className="rounded bg-slate-900 border-slate-700 text-cyan-500 focus:ring-0"
              />
            </button>

            {/* Toggle 3: Contact Info */}
            <button
              onClick={() => handleToggleCategory('maskContacts')}
              className={`p-2.5 rounded-xl border text-left transition flex items-center justify-between ${
                options.maskContacts
                  ? 'bg-cyan-950/60 border-cyan-800 text-cyan-300'
                  : 'bg-slate-950 border-slate-800 text-slate-500 hover:text-slate-400'
              }`}
            >
              <div>
                <span className="font-bold block text-xs">Email & Phone</span>
                <span className="text-[10px] opacity-70 block">Contact Identifiers</span>
              </div>
              <input
                type="checkbox"
                checked={options.maskContacts}
                onChange={() => {}}
                className="rounded bg-slate-900 border-slate-700 text-cyan-500 focus:ring-0"
              />
            </button>

            {/* Toggle 4: Handles */}
            <button
              onClick={() => handleToggleCategory('maskHandles')}
              className={`p-2.5 rounded-xl border text-left transition flex items-center justify-between ${
                options.maskHandles
                  ? 'bg-cyan-950/60 border-cyan-800 text-cyan-300'
                  : 'bg-slate-950 border-slate-800 text-slate-500 hover:text-slate-400'
              }`}
            >
              <div>
                <span className="font-bold block text-xs">Handles & Usernames</span>
                <span className="text-[10px] opacity-70 block">Social & Platform IDs</span>
              </div>
              <input
                type="checkbox"
                checked={options.maskHandles}
                onChange={() => {}}
                className="rounded bg-slate-900 border-slate-700 text-cyan-500 focus:ring-0"
              />
            </button>

            {/* Toggle 5: Network IPs */}
            <button
              onClick={() => handleToggleCategory('maskNetwork')}
              className={`p-2.5 rounded-xl border text-left transition flex items-center justify-between ${
                options.maskNetwork
                  ? 'bg-cyan-950/60 border-cyan-800 text-cyan-300'
                  : 'bg-slate-950 border-slate-800 text-slate-500 hover:text-slate-400'
              }`}
            >
              <div>
                <span className="font-bold block text-xs">IP & Network Nodes</span>
                <span className="text-[10px] opacity-70 block">IPv4/IPv6 Addresses</span>
              </div>
              <input
                type="checkbox"
                checked={options.maskNetwork}
                onChange={() => {}}
                className="rounded bg-slate-900 border-slate-700 text-cyan-500 focus:ring-0"
              />
            </button>

          </div>
        </div>
      )}

    </div>
  );
};
