import React, { useState } from 'react';
import { ShieldCheck, AlertCircle, AlertTriangle, CheckSquare, Square, Zap, Lock, Eye, ShieldAlert } from 'lucide-react';
import { ThreatVector } from '../types';

interface ThreatVectorsCardProps {
  threatVectors: ThreatVector[];
  recommendations: string[];
}

export const ThreatVectorsCard: React.FC<ThreatVectorsCardProps> = ({ threatVectors, recommendations }) => {
  const [completedTasks, setCompletedTasks] = useState<Record<number, boolean>>({});

  const toggleTask = (idx: number) => {
    setCompletedTasks((prev) => ({ ...prev, [idx]: !prev[idx] }));
  };

  const completedCount = Object.values(completedTasks).filter(Boolean).length;

  const getStatusColor = (status: ThreatVector['status']) => {
    switch (status) {
      case 'ALERT': return { text: 'text-red-400', bg: 'bg-red-500' };
      case 'WARNING': return { text: 'text-amber-400', bg: 'bg-amber-400' };
      default: return { text: 'text-emerald-400', bg: 'bg-emerald-400' };
    }
  };

  return (
    <div className="bg-slate-900 rounded-2xl border border-slate-800 p-5 sm:p-6 shadow-xl space-y-6">
      
      {/* Header */}
      <div>
        <h3 className="text-xl font-bold font-mono text-slate-100 flex items-center space-x-2">
          <Zap className="w-5 h-5 text-amber-400" />
          <span>Threat Vector Analysis & Exposure Index</span>
        </h3>
        <p className="text-xs text-slate-400 font-mono mt-0.5">
          Calculated attack surface metrics and actionable defense recommendations.
        </p>
      </div>

      {/* Threat Metrics Progress Bars */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {threatVectors.map((tv, idx) => {
          const style = getStatusColor(tv.status);

          return (
            <div key={idx} className="bg-slate-950 p-4 rounded-xl border border-slate-800/80 font-mono">
              <div className="flex items-center justify-between mb-2">
                <span className="font-bold text-slate-200 text-sm">{tv.category}</span>
                <span className={`text-xs font-bold ${style.text}`}>{tv.score}% Exposure</span>
              </div>

              {/* Progress Track */}
              <div className="w-full h-2 bg-slate-800 rounded-full overflow-hidden mb-2">
                <div
                  className={`h-full ${style.bg} rounded-full transition-all duration-500`}
                  style={{ width: `${tv.score}%` }}
                ></div>
              </div>

              <p className="text-xs text-slate-400 leading-relaxed">{tv.description}</p>
            </div>
          );
        })}
      </div>

      {/* Actionable Defense Checklist */}
      <div className="pt-4 border-t border-slate-800">
        <div className="flex items-center justify-between mb-3 font-mono">
          <h4 className="font-bold text-slate-100 text-sm flex items-center space-x-2">
            <ShieldCheck className="w-4 h-4 text-emerald-400" />
            <span>Remediation & Defense Checklist</span>
          </h4>
          <span className="text-xs text-slate-400">
            {completedCount} of {recommendations.length} Mitigated
          </span>
        </div>

        <div className="space-y-2">
          {recommendations.map((rec, idx) => {
            const isDone = !!completedTasks[idx];

            return (
              <div
                key={idx}
                onClick={() => toggleTask(idx)}
                className={`p-3 rounded-xl border cursor-pointer font-mono text-xs flex items-start space-x-3 transition ${
                  isDone
                    ? 'bg-emerald-950/40 border-emerald-800/60 text-slate-400 line-through'
                    : 'bg-slate-950 border-slate-800 hover:border-slate-700 text-slate-200'
                }`}
              >
                <div className="mt-0.5 shrink-0 text-cyan-400">
                  {isDone ? <CheckSquare className="w-4 h-4 text-emerald-400" /> : <Square className="w-4 h-4 text-slate-500" />}
                </div>
                <span className="leading-relaxed">{rec}</span>
              </div>
            );
          })}
        </div>
      </div>

    </div>
  );
};
