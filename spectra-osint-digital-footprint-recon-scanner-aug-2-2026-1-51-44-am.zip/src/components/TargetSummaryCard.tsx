import React from 'react';
import { ShieldAlert, ShieldCheck, AlertTriangle, ExternalLink, MapPin, Calendar, User, Search, Copy, Check, Info } from 'lucide-react';
import { OsintResult, RiskLevel } from '../types';

interface TargetSummaryCardProps {
  result: OsintResult;
}

export const TargetSummaryCard: React.FC<TargetSummaryCardProps> = ({ result }) => {
  const [copied, setCopied] = React.useState(false);
  const { targetSummary, query, queryType, scanDurationMs, rawSearchGroundingSources } = result;

  const handleCopyHash = () => {
    const payload = `OSINT RECON REPORT\nTarget: ${query}\nType: ${queryType}\nRisk Score: ${targetSummary.overallRiskScore}/100 (${targetSummary.riskLevel})\nProfiles Found: ${targetSummary.totalProfilesFound}\nBreaches Found: ${targetSummary.totalBreachesFound}\nTimestamp: ${result.timestamp}`;
    navigator.clipboard.writeText(payload);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const getRiskColor = (level: RiskLevel) => {
    switch (level) {
      case 'CRITICAL': return { text: 'text-red-400', bg: 'bg-red-950/80', border: 'border-red-800', badge: 'bg-red-500 text-slate-950' };
      case 'HIGH': return { text: 'text-orange-400', bg: 'bg-orange-950/80', border: 'border-orange-800', badge: 'bg-orange-500 text-slate-950' };
      case 'MEDIUM': return { text: 'text-amber-400', bg: 'bg-amber-950/80', border: 'border-amber-800', badge: 'bg-amber-400 text-slate-950' };
      default: return { text: 'text-emerald-400', bg: 'bg-emerald-950/80', border: 'border-emerald-800', badge: 'bg-emerald-400 text-slate-950' };
    }
  };

  const riskStyle = getRiskColor(targetSummary.riskLevel);

  return (
    <div className="bg-slate-900 rounded-2xl border border-slate-800 p-5 sm:p-6 shadow-xl relative overflow-hidden">
      
      {/* Decorative Cyber Grid Background */}
      <div className="absolute top-0 right-0 w-96 h-96 bg-cyan-500/5 rounded-full blur-3xl pointer-events-none"></div>

      <div className="flex flex-col lg:flex-row items-start lg:items-center justify-between gap-6 relative z-10">
        
        {/* Left: Avatar & Identity Details */}
        <div className="flex items-start space-x-4">
          <div className="relative">
            {targetSummary.avatarUrl ? (
              <img
                src={targetSummary.avatarUrl}
                alt="Target avatar"
                className="w-16 h-16 sm:w-20 sm:h-20 rounded-2xl object-cover border-2 border-slate-700 shadow-md bg-slate-950"
              />
            ) : (
              <div className="w-16 h-16 sm:w-20 sm:h-20 rounded-2xl bg-slate-950 border-2 border-slate-700 flex items-center justify-center text-cyan-400">
                <User className="w-8 h-8" />
              </div>
            )}
            <span
              className={`absolute -bottom-1 -right-1 px-2 py-0.5 rounded-full text-[10px] font-mono font-bold uppercase shadow-sm ${riskStyle.badge}`}
            >
              {targetSummary.riskLevel}
            </span>
          </div>

          <div>
            <div className="flex flex-wrap items-center gap-2 mb-1">
              <h2 className="text-xl sm:text-2xl font-bold font-mono text-slate-100 break-all">{query}</h2>
              <span className="px-2 py-0.5 rounded text-xs font-mono font-semibold bg-slate-800 text-slate-300 border border-slate-700 uppercase">
                {queryType}
              </span>
            </div>

            <div className="flex flex-wrap items-center gap-y-1 gap-x-4 text-xs font-mono text-slate-400 mb-2">
              {targetSummary.fullNameCandidate && (
                <span className="flex items-center space-x-1 text-cyan-300 font-semibold">
                  <span>Candidate: {targetSummary.fullNameCandidate}</span>
                </span>
              )}
              {targetSummary.locationCandidate && (
                <span className="flex items-center space-x-1 text-slate-400">
                  <MapPin className="w-3.5 h-3.5 text-slate-500" />
                  <span>{targetSummary.locationCandidate}</span>
                </span>
              )}
              <span className="flex items-center space-x-1 text-slate-500">
                <Calendar className="w-3.5 h-3.5" />
                <span>Last Activity: {targetSummary.lastSeenDate || 'Recent'}</span>
              </span>
            </div>

            <p className="text-xs sm:text-sm text-slate-300 leading-relaxed max-w-2xl">
              {targetSummary.summaryText}
            </p>
          </div>
        </div>

        {/* Right: Risk Gauge & Quick Metrics */}
        <div className="w-full lg:w-auto flex items-center justify-between lg:justify-end gap-4 sm:gap-6 border-t lg:border-t-0 border-slate-800 pt-4 lg:pt-0">
          
          {/* Risk Score Circle / Dial */}
          <div className={`p-4 rounded-2xl border ${riskStyle.border} ${riskStyle.bg} flex flex-col items-center justify-center min-w-[120px] text-center`}>
            <span className="text-[10px] font-mono font-bold tracking-wider text-slate-400 uppercase mb-1">OVERALL RISK</span>
            <div className="flex items-baseline space-x-1">
              <span className={`text-3xl sm:text-4xl font-extrabold font-mono ${riskStyle.text}`}>
                {targetSummary.overallRiskScore}
              </span>
              <span className="text-xs font-mono text-slate-400">/100</span>
            </div>
            <span className={`mt-1 text-[11px] font-mono font-bold ${riskStyle.text}`}>
              {targetSummary.riskLevel} THREAT
            </span>
          </div>

          {/* Key Numbers Grid */}
          <div className="grid grid-cols-2 gap-2 text-center text-xs font-mono">
            <div className="p-3 bg-slate-950 rounded-xl border border-slate-800 min-w-[90px]">
              <span className="block text-slate-500 text-[10px]">PROFILES</span>
              <span className="text-lg font-bold text-cyan-400">{targetSummary.totalProfilesFound}</span>
            </div>
            <div className="p-3 bg-slate-950 rounded-xl border border-slate-800 min-w-[90px]">
              <span className="block text-slate-500 text-[10px]">BREACHES</span>
              <span className={`text-lg font-bold ${targetSummary.totalBreachesFound > 0 ? 'text-red-400' : 'text-emerald-400'}`}>
                {targetSummary.totalBreachesFound}
              </span>
            </div>
          </div>

        </div>

      </div>

      {/* Footer Meta & Grounding Citations */}
      <div className="mt-5 pt-4 border-t border-slate-800/80 flex flex-wrap items-center justify-between gap-3 text-xs font-mono text-slate-400">
        
        <div className="flex flex-wrap items-center gap-3">
          <span className="flex items-center space-x-1 text-slate-500">
            <Info className="w-3.5 h-3.5 text-cyan-500" />
            <span>Confidence Index: <strong className="text-slate-200">{targetSummary.confidenceScore}%</strong></span>
          </span>
          <span className="text-slate-600">•</span>
          <span>Scan Latency: <strong className="text-slate-300">{scanDurationMs}ms</strong></span>
        </div>

        <button
          onClick={handleCopyHash}
          className="px-2.5 py-1 rounded bg-slate-800 hover:bg-slate-700 text-slate-300 border border-slate-700 flex items-center space-x-1.5 transition text-xs"
        >
          {copied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5 text-cyan-400" />}
          <span>{copied ? 'Report Copied' : 'Copy Key Hash'}</span>
        </button>

      </div>

      {/* Grounded Web Sources if present */}
      {rawSearchGroundingSources && rawSearchGroundingSources.length > 0 && (
        <div className="mt-3 pt-3 border-t border-slate-800/60 text-xs font-mono">
          <span className="text-slate-500 block mb-1.5 font-semibold">Grounded Web Citations ({rawSearchGroundingSources.length}):</span>
          <div className="flex flex-wrap gap-2">
            {rawSearchGroundingSources.slice(0, 5).map((src, i) => (
              <a
                key={i}
                href={src.url}
                target="_blank"
                rel="noreferrer"
                className="px-2 py-0.5 rounded bg-slate-950 border border-slate-800 text-cyan-400 hover:text-cyan-300 flex items-center space-x-1 truncate max-w-xs transition"
              >
                <ExternalLink className="w-3 h-3 shrink-0" />
                <span className="truncate">{src.title}</span>
              </a>
            ))}
          </div>
        </div>
      )}

    </div>
  );
};
