import React, { useState } from 'react';
import { Search, Mail, Phone, AtSign, Globe, Cpu, Zap, Shield, Sparkles, Filter, ChevronDown, Check, Camera } from 'lucide-react';
import { QueryType, ScanDepth } from '../types';
import { DEMO_TARGETS, DemoTarget } from '../data/mockDemos';

interface SearchHeaderProps {
  onSearch: (query: string, type: QueryType, depth: ScanDepth) => void;
  onSelectDemo: (demo: DemoTarget) => void;
  onSelectImageForensics?: () => void;
  isScanning: boolean;
}

export const SearchHeader: React.FC<SearchHeaderProps> = ({ onSearch, onSelectDemo, onSelectImageForensics, isScanning }) => {
  const [query, setQuery] = useState('');
  const [selectedType, setSelectedType] = useState<QueryType>('auto');
  const [scanDepth, setScanDepth] = useState<ScanDepth>('deep');
  const [showFilters, setShowFilters] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!query.trim()) return;
    onSearch(query.trim(), selectedType, scanDepth);
  };

  const getPlaceholder = () => {
    switch (selectedType) {
      case 'email': return 'Enter email address (e.g., target.user@domain.com)...';
      case 'phone': return 'Enter mobile or landline phone number (e.g., +1 415 555 0192)...';
      case 'username': return 'Enter handle or social username (e.g., @cyber_ghost_99)...';
      case 'domain': return 'Enter target domain or IP address (e.g., company.com)...';
      case 'image': return 'Click "Launch Image Forensics" or select Image Forensics module...';
      default: return 'Enter Email, Phone Number (+1...), Username (@handle), or Domain...';
    }
  };

  return (
    <div className="bg-slate-900 border-b border-slate-800 pt-8 pb-10 px-4 sm:px-6 lg:px-8">
      <div className="max-w-4xl mx-auto text-center">
        
        {/* Title & Eyebrow */}
        <div className="inline-flex items-center space-x-2 px-3 py-1 rounded-full bg-cyan-950/80 border border-cyan-800/80 text-cyan-400 text-xs font-mono mb-4">
          <Sparkles className="w-3.5 h-3.5 text-cyan-400 animate-spin" style={{ animationDuration: '4s' }} />
          <span>REAL-TIME OSINT CRAWLER, EXIF FORENSICS & BREACH AGGREGATOR</span>
        </div>

        <h1 className="text-3xl sm:text-4xl lg:text-5xl font-extrabold text-slate-100 tracking-tight mb-3">
          Deep Web & Digital Footprint Recon
        </h1>
        <p className="text-slate-400 text-sm sm:text-base max-w-2xl mx-auto mb-8 leading-relaxed">
          Search public networks, leaked credential repositories, WHOIS domain registers, carrier metadata, and extract real-time EXIF image forensics (snapped phone details, camera click settings, and GPS geotags).
        </p>

        {/* Search Input Box Card */}
        <div className="bg-slate-950/90 rounded-2xl p-3 sm:p-4 border border-slate-800 shadow-2xl shadow-cyan-950/30">
          
          {/* Query Type / Investigation Section Tabs */}
          <div className="flex flex-wrap items-center justify-center gap-1.5 sm:gap-2 mb-3 pb-3 border-b border-slate-800/80 text-xs font-mono">
            <button
              type="button"
              onClick={() => setSelectedType('auto')}
              className={`px-3 py-1.5 rounded-lg font-medium transition flex items-center space-x-1.5 ${
                selectedType === 'auto'
                  ? 'bg-cyan-600 text-white shadow-sm shadow-cyan-600/40'
                  : 'bg-slate-900 text-slate-400 hover:text-slate-200 hover:bg-slate-800'
              }`}
            >
              <Cpu className="w-3.5 h-3.5" />
              <span>Auto Detect</span>
            </button>

            <button
              type="button"
              onClick={() => setSelectedType('email')}
              className={`px-3 py-1.5 rounded-lg font-medium transition flex items-center space-x-1.5 ${
                selectedType === 'email'
                  ? 'bg-cyan-600 text-white shadow-sm shadow-cyan-600/40'
                  : 'bg-slate-900 text-slate-400 hover:text-slate-200 hover:bg-slate-800'
              }`}
            >
              <Mail className="w-3.5 h-3.5" />
              <span>Email Recon</span>
            </button>

            <button
              type="button"
              onClick={() => setSelectedType('phone')}
              className={`px-3 py-1.5 rounded-lg font-medium transition flex items-center space-x-1.5 ${
                selectedType === 'phone'
                  ? 'bg-cyan-600 text-white shadow-sm shadow-cyan-600/40'
                  : 'bg-slate-900 text-slate-400 hover:text-slate-200 hover:bg-slate-800'
              }`}
            >
              <Phone className="w-3.5 h-3.5" />
              <span>Phone & Carrier</span>
            </button>

            <button
              type="button"
              onClick={() => setSelectedType('username')}
              className={`px-3 py-1.5 rounded-lg font-medium transition flex items-center space-x-1.5 ${
                selectedType === 'username'
                  ? 'bg-cyan-600 text-white shadow-sm shadow-cyan-600/40'
                  : 'bg-slate-900 text-slate-400 hover:text-slate-200 hover:bg-slate-800'
              }`}
            >
              <AtSign className="w-3.5 h-3.5" />
              <span>Username Handle</span>
            </button>

            <button
              type="button"
              onClick={() => setSelectedType('domain')}
              className={`px-3 py-1.5 rounded-lg font-medium transition flex items-center space-x-1.5 ${
                selectedType === 'domain'
                  ? 'bg-cyan-600 text-white shadow-sm shadow-cyan-600/40'
                  : 'bg-slate-900 text-slate-400 hover:text-slate-200 hover:bg-slate-800'
              }`}
            >
              <Globe className="w-3.5 h-3.5" />
              <span>Domain / IP</span>
            </button>

            {onSelectImageForensics && (
              <button
                type="button"
                onClick={onSelectImageForensics}
                className="px-3 py-1.5 rounded-lg font-bold bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-500 hover:to-indigo-500 text-white transition flex items-center space-x-1.5 shadow-sm shadow-purple-600/40"
              >
                <Camera className="w-3.5 h-3.5 text-purple-200" />
                <span>Image Forensics</span>
              </button>
            )}
          </div>

          {/* Form */}
          <form onSubmit={handleSubmit} className="flex flex-col sm:flex-row items-center gap-2">
            <div className="relative w-full flex-1">
              <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-slate-500">
                <Search className="w-5 h-5 text-cyan-500" />
              </div>
              <input
                type="text"
                value={query}
                onChange={(e) => setQuery(e.target.value)}
                placeholder={getPlaceholder()}
                className="w-full pl-11 pr-4 py-3.5 bg-slate-900 border border-slate-800 focus:border-cyan-500 focus:ring-1 focus:ring-cyan-500 rounded-xl text-slate-100 placeholder-slate-500 text-sm font-mono transition"
                disabled={isScanning}
              />
            </div>

            <button
              type="submit"
              disabled={isScanning || !query.trim()}
              className="w-full sm:w-auto px-6 py-3.5 bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 text-slate-950 font-bold text-sm rounded-xl flex items-center justify-center space-x-2 transition shadow-lg shadow-cyan-500/20 disabled:opacity-50 disabled:cursor-not-allowed whitespace-nowrap"
            >
              {isScanning ? (
                <>
                  <Zap className="w-4 h-4 animate-spin" />
                  <span>Scanning...</span>
                </>
              ) : (
                <>
                  <Shield className="w-4 h-4" />
                  <span>Launch OSINT Scan</span>
                </>
              )}
            </button>
          </form>

          {/* Advanced Scan Options bar */}
          <div className="mt-3 pt-3 border-t border-slate-900 flex flex-wrap items-center justify-between text-xs text-slate-400 font-mono gap-2 px-1">
            <div className="flex items-center space-x-3">
              <span className="text-slate-500">Scan Mode:</span>
              <button
                type="button"
                onClick={() => setScanDepth('standard')}
                className={`px-2 py-0.5 rounded border ${
                  scanDepth === 'standard' ? 'bg-cyan-950 text-cyan-400 border-cyan-800' : 'bg-slate-900 text-slate-500 border-slate-800'
                }`}
              >
                Standard Surface
              </button>
              <button
                type="button"
                onClick={() => setScanDepth('deep')}
                className={`px-2 py-0.5 rounded border flex items-center space-x-1 ${
                  scanDepth === 'deep' ? 'bg-indigo-950 text-indigo-400 border-indigo-800' : 'bg-slate-900 text-slate-500 border-slate-800'
                }`}
              >
                <Zap className="w-3 h-3 text-indigo-400" />
                <span>Deep Grounded Intelligence</span>
              </button>
            </div>

            <button
              type="button"
              onClick={() => setShowFilters(!showFilters)}
              className="text-slate-400 hover:text-cyan-400 flex items-center space-x-1 transition"
            >
              <Filter className="w-3.5 h-3.5" />
              <span>Target Surface Filters</span>
              <ChevronDown className={`w-3.5 h-3.5 transition-transform ${showFilters ? 'rotate-180' : ''}`} />
            </button>
          </div>

          {/* Collapsible Filter Matrix */}
          {showFilters && (
            <div className="mt-3 p-3 bg-slate-900/90 rounded-xl border border-slate-800 text-left text-xs font-mono grid grid-cols-2 sm:grid-cols-4 gap-2">
              <label className="flex items-center space-x-2 text-slate-300 cursor-pointer">
                <input type="checkbox" defaultChecked className="rounded border-slate-700 bg-slate-800 text-cyan-500 focus:ring-0" />
                <span>Social Networks (300+)</span>
              </label>
              <label className="flex items-center space-x-2 text-slate-300 cursor-pointer">
                <input type="checkbox" defaultChecked className="rounded border-slate-700 bg-slate-800 text-cyan-500 focus:ring-0" />
                <span>Breach & Paste Dumps</span>
              </label>
              <label className="flex items-center space-x-2 text-slate-300 cursor-pointer">
                <input type="checkbox" defaultChecked className="rounded border-slate-700 bg-slate-800 text-cyan-500 focus:ring-0" />
                <span>Developer & Git Repos</span>
              </label>
              <label className="flex items-center space-x-2 text-slate-300 cursor-pointer">
                <input type="checkbox" defaultChecked className="rounded border-slate-700 bg-slate-800 text-cyan-500 focus:ring-0" />
                <span>Carrier & WHOIS Lookup</span>
              </label>
            </div>
          )}

        </div>

        {/* Demo Targets Quick Launch */}
        <div className="mt-6 flex flex-wrap items-center justify-center gap-2">
          <span className="text-xs font-mono text-slate-500 mr-1">Quick Sample Investigations:</span>
          {DEMO_TARGETS.map((demo) => (
            <button
              key={demo.id}
              onClick={() => {
                setQuery(demo.query);
                setSelectedType(demo.type);
                onSelectDemo(demo);
              }}
              className="px-3 py-1 rounded-full bg-slate-800/80 hover:bg-slate-800 border border-slate-700 text-slate-300 text-xs font-mono flex items-center space-x-2 transition group"
            >
              <span className="w-1.5 h-1.5 rounded-full bg-cyan-400 group-hover:scale-125 transition"></span>
              <span className="font-semibold text-slate-200">{demo.query}</span>
              <span className="text-[10px] text-slate-500 bg-slate-900 px-1.5 py-0.2 rounded border border-slate-800">{demo.badge}</span>
            </button>
          ))}
        </div>

      </div>
    </div>
  );
};
