import React from 'react';
import { ShieldAlert, Terminal, History, Scale, FileText, ShieldCheck, Lock, Eye } from 'lucide-react';
import { AnonymizationLevel } from '../types';

interface NavbarProps {
  onOpenHistory: () => void;
  onOpenCompliance: () => void;
  onOpenExport?: () => void;
  isScanning: boolean;
  historyCount: number;
  hasResult: boolean;
  anonymizationLevel?: AnonymizationLevel;
  onToggleAnonymization?: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  onOpenHistory,
  onOpenCompliance,
  onOpenExport,
  isScanning,
  historyCount,
  hasResult,
  anonymizationLevel = 'PARTIAL',
  onToggleAnonymization,
}) => {
  const getPrivacyBadge = () => {
    switch (anonymizationLevel) {
      case 'FULL':
        return {
          bg: 'bg-purple-950 text-purple-300 border-purple-800',
          label: 'ANONYMOUS (FULL)',
          icon: <Lock className="w-3.5 h-3.5 text-purple-400" />,
        };
      case 'PARTIAL':
        return {
          bg: 'bg-cyan-950 text-cyan-300 border-cyan-800',
          label: 'MASKED (PARTIAL)',
          icon: <ShieldCheck className="w-3.5 h-3.5 text-cyan-400" />,
        };
      default:
        return {
          bg: 'bg-amber-950 text-amber-300 border-amber-800',
          label: 'RAW (UNMASKED)',
          icon: <Eye className="w-3.5 h-3.5 text-amber-400" />,
        };
    }
  };

  const badge = getPrivacyBadge();

  return (
    <header className="sticky top-0 z-40 bg-slate-900/90 backdrop-blur-md border-b border-slate-800 text-slate-100">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between">
        
        {/* Brand Identity */}
        <div className="flex items-center space-x-3">
          <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-cyan-600 via-blue-600 to-indigo-600 flex items-center justify-center shadow-lg shadow-cyan-500/20 border border-cyan-400/30">
            <ShieldAlert className="w-5 h-5 text-white animate-pulse" />
          </div>
          <div>
            <div className="flex items-center space-x-2">
              <span className="font-mono font-bold tracking-wider text-lg text-slate-100">SPECTRA</span>
              <span className="px-1.5 py-0.5 rounded text-[10px] font-mono font-semibold bg-cyan-950 text-cyan-400 border border-cyan-800/60 uppercase">
                OSINT RECON v3.6
              </span>
            </div>
            <p className="text-xs text-slate-400 hidden sm:block">Digital Footprint & Threat Intelligence Engine</p>
          </div>
        </div>

        {/* Status & Privacy Indicator */}
        <div className="hidden md:flex items-center space-x-3 font-mono text-xs">
          <div className="flex items-center space-x-2 px-3 py-1.5 rounded-full bg-slate-950/80 border border-slate-800">
            <span className={`w-2 h-2 rounded-full ${isScanning ? 'bg-amber-400 animate-ping' : 'bg-emerald-400 animate-pulse'}`}></span>
            <span className="text-slate-300">
              {isScanning ? 'RECON ENGINE: SCANNING...' : 'GROUNDED OSINT: READY'}
            </span>
          </div>

          {onToggleAnonymization && (
            <button
              onClick={onToggleAnonymization}
              className={`px-3 py-1.5 rounded-full border text-[11px] font-bold flex items-center space-x-1.5 transition ${badge.bg}`}
              title="Click to toggle privacy anonymization level"
            >
              {badge.icon}
              <span>PRIVACY: {badge.label}</span>
            </button>
          )}
        </div>

        {/* Action Controls */}
        <div className="flex items-center space-x-2 sm:space-x-3">
          {hasResult && onOpenExport && (
            <button
              onClick={onOpenExport}
              className="px-3 py-1.5 rounded-lg bg-cyan-600 hover:bg-cyan-500 text-white font-medium text-xs sm:text-sm flex items-center space-x-1.5 transition shadow-sm shadow-cyan-600/30"
            >
              <FileText className="w-4 h-4" />
              <span>Export Report</span>
            </button>
          )}

          <button
            onClick={onOpenHistory}
            className="px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 text-xs sm:text-sm font-medium flex items-center space-x-1.5 transition relative"
            title="Investigation Locker & History"
          >
            <History className="w-4 h-4 text-cyan-400" />
            <span className="hidden sm:inline">Locker</span>
            {historyCount > 0 && (
              <span className="ml-1 px-1.5 py-0.2 rounded-full text-[10px] font-mono font-bold bg-cyan-500 text-slate-950">
                {historyCount}
              </span>
            )}
          </button>

          <button
            onClick={onOpenCompliance}
            className="p-2 sm:px-3 sm:py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 border border-slate-700 text-xs sm:text-sm font-medium flex items-center space-x-1.5 transition"
            title="Ethical Standard & Compliance"
          >
            <Scale className="w-4 h-4 text-amber-400" />
            <span className="hidden sm:inline">Ethics & Policy</span>
          </button>
        </div>

      </div>
    </header>
  );
};
