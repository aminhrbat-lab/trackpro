import React from 'react';
import { X, History, Trash2, ArrowRight, Shield, Clock } from 'lucide-react';
import { SearchHistoryItem } from '../types';

interface HistoryDrawerProps {
  history: SearchHistoryItem[];
  onSelectHistoryItem: (item: SearchHistoryItem) => void;
  onClearHistory: () => void;
  onClose: () => void;
}

export const HistoryDrawer: React.FC<HistoryDrawerProps> = ({
  history,
  onSelectHistoryItem,
  onClearHistory,
  onClose,
}) => {
  return (
    <div className="fixed inset-0 z-50 flex justify-end bg-slate-950/80 backdrop-blur-sm animate-fade-in">
      <div className="bg-slate-900 border-l border-slate-800 w-full max-w-md h-full flex flex-col shadow-2xl font-mono text-xs text-slate-300">
        
        {/* Header */}
        <div className="p-4 border-b border-slate-800 flex items-center justify-between bg-slate-950">
          <div className="flex items-center space-x-2">
            <History className="w-5 h-5 text-cyan-400" />
            <h3 className="font-bold text-slate-100 text-sm">Investigation Locker & History</h3>
          </div>

          <button
            onClick={onClose}
            className="p-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-400 hover:text-slate-200 transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* History Item List */}
        <div className="flex-1 overflow-y-auto p-4 space-y-3">
          {history.length === 0 ? (
            <div className="text-center py-16 text-slate-500 space-y-2">
              <Clock className="w-8 h-8 text-slate-600 mx-auto" />
              <p>No previous investigations logged in local locker.</p>
            </div>
          ) : (
            history.map((item) => (
              <div
                key={item.id}
                onClick={() => onSelectHistoryItem(item)}
                className="p-3.5 bg-slate-950 rounded-xl border border-slate-800 hover:border-cyan-500/50 cursor-pointer transition flex items-center justify-between group"
              >
                <div>
                  <div className="flex items-center space-x-2 mb-1">
                    <span className="font-bold text-slate-100 group-hover:text-cyan-300 transition truncate max-w-[200px]">
                      {item.query}
                    </span>
                    <span className="px-1.5 py-0.2 rounded bg-slate-800 text-slate-400 text-[10px] uppercase">
                      {item.queryType}
                    </span>
                  </div>

                  <div className="flex items-center space-x-3 text-[11px] text-slate-400">
                    <span className="text-red-400 font-semibold">Risk: {item.riskScore}/100</span>
                    <span>Profiles: {item.profilesCount}</span>
                    <span>Breaches: {item.breachesCount}</span>
                  </div>
                </div>

                <ArrowRight className="w-4 h-4 text-slate-600 group-hover:text-cyan-400 transition transform group-hover:translate-x-1" />
              </div>
            ))
          )}
        </div>

        {/* Footer */}
        {history.length > 0 && (
          <div className="p-4 border-t border-slate-800 bg-slate-950 flex justify-between items-center">
            <span className="text-slate-500 text-[11px]">{history.length} saved target records</span>
            <button
              onClick={onClearHistory}
              className="px-3 py-1.5 rounded bg-red-950 hover:bg-red-900 border border-red-800 text-red-300 font-medium flex items-center space-x-1.5 transition"
            >
              <Trash2 className="w-3.5 h-3.5" />
              <span>Clear Locker</span>
            </button>
          </div>
        )}

      </div>
    </div>
  );
};
