export type QueryType = 'auto' | 'email' | 'phone' | 'username' | 'domain' | 'ip' | 'image';

export type RiskLevel = 'LOW' | 'MEDIUM' | 'HIGH' | 'CRITICAL';

export type ScanDepth = 'standard' | 'deep';

export type AnonymizationLevel = 'OFF' | 'PARTIAL' | 'FULL';

export interface AnonymizationOptions {
  level: AnonymizationLevel;
  maskNames: boolean;       // Mask full names and person candidates
  maskLocations: boolean;   // Mask physical addresses and locations
  maskContacts: boolean;    // Mask emails and phone numbers
  maskHandles: boolean;     // Mask usernames and platform handles
  maskNetwork: boolean;     // Mask IP addresses and domains
}

export interface ExifDeviceData {
  make?: string;
  model?: string;
  lensModel?: string;
  software?: string;
  serialNumber?: string;
  deviceOwner?: string;
}

export interface ExifClickData {
  shutterSpeed?: string;
  aperture?: string;
  iso?: string;
  focalLength?: string;
  exposureProgram?: string;
  exposureCompensation?: string;
  flashFired?: string;
  meteringMode?: string;
  whiteBalance?: string;
  brightness?: string;
}

export interface ExifGpsData {
  latitude?: number;
  longitude?: number;
  altitude?: string;
  gpsTimestamp?: string;
  gpsSpeed?: string;
  locationName?: string;
  mapsUrl?: string;
}

export interface ExifImageData {
  fileName?: string;
  fileSize?: string;
  mimeType?: string;
  dimensions?: string;
  megapixels?: string;
  colorSpace?: string;
  orientation?: string;
  hasExifData: boolean;
}

export interface ImageForensicResult {
  id: string;
  imageUrl: string;
  previewUrl: string;
  timestamp: string;
  device: ExifDeviceData;
  clickDetails: ExifClickData;
  gps: ExifGpsData;
  imageSpecs: ExifImageData;
  privacyRiskScore: number; // 0-100
  privacyRiskLevel: RiskLevel;
  steganographyRisk: 'LOW' | 'MEDIUM' | 'HIGH';
  detectedLandmarks: string[];
  visibleObjects: string[];
  forensicSummary: string;
  privacyRecommendations: string[];
  rawExifJson?: Record<string, any>;
}

export interface SocialProfile {
  id: string;
  platform: string;
  category: 'Social' | 'Developer' | 'Gaming' | 'Forum' | 'Professional' | 'Financial' | 'Other';
  username: string;
  url: string;
  avatarUrl?: string;
  status: 'FOUND' | 'NOT_FOUND' | 'FLAGGED' | 'VERIFIED';
  accountAge?: string;
  lastActive?: string;
  metadata?: Record<string, string>;
  confidence: number; // 0-100
}

export interface BreachRecord {
  id: string;
  title: string;
  domain: string;
  breachDate: string;
  addedDate: string;
  pwnCount: number;
  dataClasses: string[];
  isVerified: boolean;
  isFabricated: boolean;
  isSensitive: boolean;
  isRetired: boolean;
  isSpamList: boolean;
  description: string;
  severity: 'LOW' | 'MEDIUM' | 'HIGH' | 'CRITICAL';
  exposedFields: string[];
}

export interface CarrierInfo {
  carrier?: string;
  lineType?: 'Mobile' | 'VoIP' | 'Landline' | 'Prepaid' | 'Unknown';
  country?: string;
  countryCode?: string;
  location?: string;
  valid?: boolean;
  riskScore?: number;
}

export interface DomainWhois {
  domain: string;
  registrar?: string;
  creationDate?: string;
  expirationDate?: string;
  nameServers?: string[];
  registrantCountry?: string;
  privacyShield?: boolean;
  associatedIPs?: string[];
}

export interface ThreatVector {
  category: string;
  score: number; // 0-100
  description: string;
  status: 'OK' | 'WARNING' | 'ALERT';
}

export interface TimelineEvent {
  id: string;
  date: string;
  title: string;
  category: 'Account Creation' | 'Data Breach' | 'Domain Register' | 'Public Mention' | 'Security Alert';
  description: string;
  source: string;
  severity?: 'info' | 'warning' | 'danger';
}

export interface NetworkNode {
  id: string;
  label: string;
  type: 'target' | 'email' | 'phone' | 'profile' | 'breach' | 'domain' | 'ip';
  risk?: RiskLevel;
  icon?: string;
}

export interface NetworkLink {
  source: string;
  target: string;
  label?: string;
}

export interface OsintResult {
  query: string;
  queryType: QueryType;
  timestamp: string;
  scanDurationMs: number;
  scanDepth: ScanDepth;
  
  targetSummary: {
    primaryAlias?: string;
    fullNameCandidate?: string;
    avatarUrl?: string;
    locationCandidate?: string;
    overallRiskScore: number; // 0-100
    riskLevel: RiskLevel;
    confidenceScore: number;
    totalProfilesFound: number;
    totalBreachesFound: number;
    firstSeenDate?: string;
    lastSeenDate?: string;
    summaryText: string;
  };

  carrierInfo?: CarrierInfo;
  domainWhois?: DomainWhois;
  
  profiles: SocialProfile[];
  breaches: BreachRecord[];
  threatVectors: ThreatVector[];
  timeline: TimelineEvent[];
  recommendations: string[];
  
  networkGraph: {
    nodes: NetworkNode[];
    links: NetworkLink[];
  };

  rawSearchGroundingSources?: {
    title: string;
    url: string;
  }[];
}

export interface SearchHistoryItem {
  id: string;
  query: string;
  queryType: QueryType;
  timestamp: string;
  riskScore: number;
  profilesCount: number;
  breachesCount: number;
}
