import { OsintResult } from '../types';

export interface DemoTarget {
  id: string;
  query: string;
  type: 'email' | 'phone' | 'username' | 'domain';
  title: string;
  badge: string;
  description: string;
  data: OsintResult;
}

export const DEMO_TARGETS: DemoTarget[] = [
  {
    id: 'demo-email-1',
    query: 'alex.vanderberg@gmail.com',
    type: 'email',
    title: 'High Exposure Email Footprint',
    badge: '3 Breaches • 8 Profiles',
    description: 'Developer footprint with exposed legacy credentials, GitHub profile, and WHOIS domain linkage.',
    data: {
      query: 'alex.vanderberg@gmail.com',
      queryType: 'email',
      timestamp: new Date().toISOString(),
      scanDurationMs: 1420,
      scanDepth: 'deep',
      targetSummary: {
        primaryAlias: 'alexv_dev',
        fullNameCandidate: 'Alexander Vanderberg',
        avatarUrl: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150&auto=format&fit=crop&q=80',
        locationCandidate: 'San Francisco, CA, USA',
        overallRiskScore: 78,
        riskLevel: 'HIGH',
        confidenceScore: 92,
        totalProfilesFound: 8,
        totalBreachesFound: 3,
        firstSeenDate: '2016-04-12',
        lastSeenDate: '2026-07-28',
        summaryText: 'Subject possesses a wide digital surface area. 3 historical breaches detected containing plaintext/hashed password combos. Associated with registered dev domains and multiple active developer handles.'
      },
      profiles: [
        {
          id: 'p1',
          platform: 'GitHub',
          category: 'Developer',
          username: 'alexvanderberg',
          url: 'https://github.com/alexvanderberg',
          status: 'VERIFIED',
          accountAge: '9 years',
          lastActive: '2 days ago',
          metadata: { 'Public Repos': '34', 'Followers': '182', 'PGP Key': '4F92A1B8' },
          confidence: 98
        },
        {
          id: 'p2',
          platform: 'LinkedIn',
          category: 'Professional',
          username: 'alexander-vanderberg',
          url: 'https://linkedin.com/in/alexander-vanderberg',
          status: 'VERIFIED',
          accountAge: '7 years',
          lastActive: 'Active this week',
          metadata: { 'Headline': 'Senior Systems Architect', 'Connections': '500+' },
          confidence: 95
        },
        {
          id: 'p3',
          platform: 'Twitter / X',
          category: 'Social',
          username: 'alexv_tech',
          url: 'https://x.com/alexv_tech',
          status: 'FOUND',
          accountAge: '6 years',
          lastActive: 'Yesterday',
          metadata: { 'Tweets': '1,420', 'Location': 'SF / Bay Area' },
          confidence: 88
        },
        {
          id: 'p4',
          platform: 'Gravatar',
          category: 'Other',
          username: 'alex.vanderberg',
          url: 'https://gravatar.com/alexvanderberg',
          status: 'FOUND',
          accountAge: '10 years',
          metadata: { 'Hash': '7a9c81f2...d3a', 'Primary Email': 'alex.vanderberg@gmail.com' },
          confidence: 100
        },
        {
          id: 'p5',
          platform: 'Reddit',
          category: 'Forum',
          username: 'alexv_sf',
          url: 'https://reddit.com/user/alexv_sf',
          status: 'FOUND',
          accountAge: '5 years',
          metadata: { 'Karma': '14.2k', 'Top Subs': 'r/netsec, r/devops' },
          confidence: 82
        },
        {
          id: 'p6',
          platform: 'Keybase',
          category: 'Developer',
          username: 'alexv',
          url: 'https://keybase.io/alexv',
          status: 'VERIFIED',
          accountAge: '8 years',
          metadata: { 'GPG Fingerprint': '7890 ABCD 1234 EF56', 'Verified DNS': 'vanderberg-labs.io' },
          confidence: 96
        },
        {
          id: 'p7',
          platform: 'Medium',
          category: 'Social',
          username: '@alexvanderberg',
          url: 'https://medium.com/@alexvanderberg',
          status: 'FOUND',
          accountAge: '4 years',
          metadata: { 'Articles': '12', 'Topics': 'Cloud Security, Kubernetes' },
          confidence: 90
        },
        {
          id: 'p8',
          platform: 'Docker Hub',
          category: 'Developer',
          username: 'alexv',
          url: 'https://hub.docker.com/u/alexv',
          status: 'FOUND',
          accountAge: '6 years',
          metadata: { 'Public Starred Repos': '18' },
          confidence: 85
        }
      ],
      breaches: [
        {
          id: 'b1',
          title: 'Collection #1 (Comb 2019)',
          domain: 'megaleak.net',
          breachDate: '2019-01-07',
          addedDate: '2019-01-16',
          pwnCount: 772904991,
          dataClasses: ['Email addresses', 'Passwords'],
          isVerified: true,
          isFabricated: false,
          isSensitive: false,
          isRetired: false,
          isSpamList: false,
          description: 'A massive compilation of credential dumps comprising over 770 million unique email addresses and passwords in cleartext/bcrypt formats.',
          severity: 'CRITICAL',
          exposedFields: ['Email', 'Plaintext Password', 'Hash']
        },
        {
          id: 'b2',
          title: 'LinkedIn Scrape (2021)',
          domain: 'linkedin.com',
          breachDate: '2021-06-22',
          addedDate: '2021-06-29',
          pwnCount: 700000000,
          dataClasses: ['Email addresses', 'Full names', 'Phone numbers', 'Professional titles', 'Work History'],
          isVerified: true,
          isFabricated: false,
          isSensitive: false,
          isRetired: false,
          isSpamList: false,
          description: 'An API scraping incident exposing data belonging to 700M LinkedIn users posted for sale on a hacker forum.',
          severity: 'HIGH',
          exposedFields: ['Email', 'Full Name', 'Phone Number', 'Employer']
        },
        {
          id: 'b3',
          title: 'Canva Breach (2019)',
          domain: 'canva.com',
          breachDate: '2019-05-24',
          addedDate: '2019-05-31',
          pwnCount: 137000000,
          dataClasses: ['Email addresses', 'Names', 'Passwords', 'Cities', 'Usernames'],
          isVerified: true,
          isFabricated: false,
          isSensitive: false,
          isRetired: false,
          isSpamList: false,
          description: 'Canva suffered a breach exposing 137M user records including bcrypt hashed passwords.',
          severity: 'MEDIUM',
          exposedFields: ['Email', 'Username', 'Bcrypt Hash', 'City']
        }
      ],
      threatVectors: [
        { category: 'Credential Exposure Risk', score: 88, description: 'Plaintext & hashed credentials found in mega compilations. High risk of credential stuffing.', status: 'ALERT' },
        { category: 'Phishing Target Vulnerability', score: 72, description: 'Publicly exposed email and full name across professional profiles makes subject prime target for spear-phishing.', status: 'WARNING' },
        { category: 'Identity Correlation', score: 95, description: 'Very high cross-linkage between professional, social, and developer handles.', status: 'ALERT' },
        { category: 'Privacy & OSINT Surface', score: 65, description: 'Gravatar hash and Keybase WHOIS links enable passive attribution.', status: 'WARNING' },
        { category: 'Darknet Exposure', score: 45, description: 'Present in major index leaks; no recent pastebin breaches in past 12 months.', status: 'OK' }
      ],
      timeline: [
        { id: 't1', date: '2016-04-12', title: 'First Gravatar Registration', category: 'Account Creation', description: 'Gravatar avatar registered for subject email address.', source: 'Gravatar API' },
        { id: 't2', date: '2017-08-19', title: 'Keybase Verification & GPG Key', category: 'Account Creation', description: 'Subject published GPG fingerprint 7890 ABCD 1234 EF56.', source: 'Keybase.io' },
        { id: 't3', date: '2019-01-07', title: 'Exposed in Collection #1', category: 'Data Breach', description: 'Email address and plaintext password appeared in mega breach database.', source: 'Collection #1 Dump', severity: 'danger' },
        { id: 't4', date: '2019-05-24', title: 'Exposed in Canva Breach', category: 'Data Breach', description: 'Account metadata and Bcrypt hash compromised in Canva breach.', source: 'Canva Leak', severity: 'warning' },
        { id: 't5', date: '2021-06-22', title: 'Exposed in LinkedIn Scrape', category: 'Data Breach', description: 'Phone number and professional title linked to target email.', source: 'RaidForums Dump', severity: 'warning' },
        { id: 't6', date: '2024-03-10', title: 'Registered Domain vanderberg-labs.io', category: 'Domain Register', description: 'WHOIS record created linking email to DNS servers.', source: 'ICANN WHOIS' }
      ],
      recommendations: [
        'Immediately change passwords for any account sharing legacy passwords found in Collection #1 dump.',
        'Enable Hardware Security Key (FIDO2 / YubiKey) or TOTP 2FA on Gmail, GitHub, and Keybase.',
        'Opt-out or request deletion of Gravatar profile or mask the email md5 hash.',
        'Implement WHOIS privacy guard on registered domain vanderberg-labs.io.',
        'Set up email alias routing for public registrations to reduce direct inbox exposure.'
      ],
      networkGraph: {
        nodes: [
          { id: 'n-target', label: 'alex.vanderberg@gmail.com', type: 'target', risk: 'HIGH' },
          { id: 'n-gh', label: 'GitHub (alexvanderberg)', type: 'profile', risk: 'LOW' },
          { id: 'n-li', label: 'LinkedIn (alexander-vanderberg)', type: 'profile', risk: 'MEDIUM' },
          { id: 'n-x', label: 'X/Twitter (alexv_tech)', type: 'profile', risk: 'LOW' },
          { id: 'n-b1', label: 'Collection #1 Breach', type: 'breach', risk: 'CRITICAL' },
          { id: 'n-b2', label: 'LinkedIn 2021 Scrape', type: 'breach', risk: 'HIGH' },
          { id: 'n-dom', label: 'vanderberg-labs.io', type: 'domain', risk: 'MEDIUM' },
          { id: 'n-ip', label: '198.51.100.42 (Cloudflare)', type: 'ip', risk: 'LOW' }
        ],
        links: [
          { source: 'n-target', target: 'n-gh', label: 'Primary Auth' },
          { source: 'n-target', target: 'n-li', label: 'Email Match' },
          { source: 'n-target', target: 'n-x', label: 'Cross-link' },
          { source: 'n-target', target: 'n-b1', label: 'Leak Found' },
          { source: 'n-target', target: 'n-b2', label: 'Scraped Data' },
          { source: 'n-target', target: 'n-dom', label: 'Registrant' },
          { source: 'n-dom', target: 'n-ip', label: 'DNS A Record' }
        ]
      }
    }
  },
  {
    id: 'demo-phone-1',
    query: '+1 (415) 890-3211',
    type: 'phone',
    title: 'Mobile Carrier & Messaging Footprint',
    badge: 'VoIP Carrier • 4 App Links',
    description: 'Phone number OSINT revealing carrier type, messaging app registrations, and associated secondary accounts.',
    data: {
      query: '+1 (415) 890-3211',
      queryType: 'phone',
      timestamp: new Date().toISOString(),
      scanDurationMs: 980,
      scanDepth: 'standard',
      targetSummary: {
        primaryAlias: '+14158903211',
        fullNameCandidate: 'Associated with Tech VoIP Line',
        locationCandidate: 'San Francisco, California, US',
        overallRiskScore: 42,
        riskLevel: 'MEDIUM',
        confidenceScore: 89,
        totalProfilesFound: 4,
        totalBreachesFound: 1,
        firstSeenDate: '2020-01-15',
        lastSeenDate: '2026-07-30',
        summaryText: 'Mobile target is a Bandwidth.com / Google Voice Virtual VoIP line. Active presence on Telegram and WhatsApp with public avatar enabled.'
      },
      carrierInfo: {
        carrier: 'Bandwidth.com CLEC (Google Voice)',
        lineType: 'VoIP',
        country: 'United States',
        countryCode: '+1',
        location: 'San Francisco, CA',
        valid: true,
        riskScore: 35
      },
      profiles: [
        {
          id: 'pp1',
          platform: 'WhatsApp',
          category: 'Social',
          username: '+14158903211',
          url: 'https://wa.me/14158903211',
          status: 'VERIFIED',
          metadata: { 'Direct Link': 'https://wa.me/14158903211', 'Account Exists': 'True', 'Profile Status': 'Active Unmasked Line' },
          confidence: 100
        },
        {
          id: 'pp2',
          platform: 'Telegram',
          category: 'Social',
          username: '+14158903211',
          url: 'https://t.me/+14158903211',
          status: 'VERIFIED',
          metadata: { 'Direct Link': 'https://t.me/+14158903211', 'Has Public Bio': 'Yes', 'Username Handle': '@sf_crypto_node' },
          confidence: 96
        },
        {
          id: 'pp3',
          platform: 'Truecaller',
          category: 'Other',
          username: 'San Francisco Caller ID',
          url: 'https://www.truecaller.com/search/us/14158903211',
          status: 'FOUND',
          metadata: { 'Direct Link': 'https://www.truecaller.com/search/us/14158903211', 'Carrier Tag': 'VoIP / Enterprise', 'Spam Score': '1%' },
          confidence: 92
        },
        {
          id: 'pp4',
          platform: 'Facebook',
          category: 'Social',
          username: '14158903211',
          url: 'https://www.facebook.com/search/top?q=14158903211',
          status: 'FOUND',
          metadata: { 'Facebook Search': '533M Public Scrape Index' },
          confidence: 88
        },
        {
          id: 'pp5',
          platform: 'Signal',
          category: 'Social',
          username: '+14158903211',
          url: 'https://signal.org',
          status: 'FOUND',
          metadata: { 'Encrypted App': 'Registered Mobile Line' },
          confidence: 91
        }
      ],
      breaches: [
        {
          id: 'pb1',
          title: 'Facebook 533M Scrape (2021)',
          domain: 'facebook.com',
          breachDate: '2021-04-03',
          addedDate: '2021-04-05',
          pwnCount: 533000000,
          dataClasses: ['Phone numbers', 'Facebook IDs', 'Full names', 'Locations', 'Gender'],
          isVerified: true,
          isFabricated: false,
          isSensitive: false,
          isRetired: false,
          isSpamList: false,
          description: 'A massive dataset containing 533 million Facebook users leaked online including phone numbers, full names, and location data.',
          severity: 'HIGH',
          exposedFields: ['Phone Number', 'FB User ID', 'City', 'Gender']
        }
      ],
      threatVectors: [
        { category: 'SIM Swap Vulnerability', score: 20, description: 'Number is on virtual VoIP network, immune to physical carrier SIM swap, but vulnerable to account takeover if email compromised.', status: 'OK' },
        { category: 'Caller ID / Robocall Spam Score', score: 15, description: 'Clean reputation score, low spam complaints.', status: 'OK' },
        { category: 'Messaging Exposure', score: 65, description: 'Active on Telegram & WhatsApp with visible profile info.', status: 'WARNING' }
      ],
      timeline: [
        { id: 'pt1', date: '2020-01-15', title: 'VoIP Line Allocation', category: 'Account Creation', description: 'Number issued via Bandwidth.com block.', source: 'North American Numbering Plan' },
        { id: 'pt2', date: '2021-04-03', title: 'Exposed in Facebook Scrape', category: 'Data Breach', description: 'Phone number mapped to FB User ID in public paste leak.', source: 'Facebook Dataset', severity: 'warning' }
      ],
      recommendations: [
        'Hide phone number visibility in Telegram Privacy & Security settings.',
        'Restrict WhatsApp profile photo visibility to contacts only.',
        'Never use SMS as 2FA backup for sensitive banking or crypto exchange accounts.'
      ],
      networkGraph: {
        nodes: [
          { id: 'n-phone', label: '+1 (415) 890-3211', type: 'target', risk: 'MEDIUM' },
          { id: 'n-tg', label: 'Telegram (@sf_crypto_node)', type: 'profile', risk: 'MEDIUM' },
          { id: 'n-wa', label: 'WhatsApp', type: 'profile', risk: 'LOW' },
          { id: 'n-fb', label: 'Facebook 533M Leak', type: 'breach', risk: 'HIGH' }
        ],
        links: [
          { source: 'n-phone', target: 'n-tg', label: 'Registered' },
          { source: 'n-phone', target: 'n-wa', label: 'Active' },
          { source: 'n-phone', target: 'n-fb', label: 'Leaked Record' }
        ]
      }
    }
  },
  {
    id: 'demo-user-1',
    query: 'cyber_ghost_99',
    type: 'username',
    title: 'Cross-Platform Username Correlation',
    badge: '6 Social Platforms Found',
    description: 'Username lookup across 500+ web platforms identifying handles, avatar consistency, and forum posts.',
    data: {
      query: 'cyber_ghost_99',
      queryType: 'username',
      timestamp: new Date().toISOString(),
      scanDurationMs: 1150,
      scanDepth: 'deep',
      targetSummary: {
        primaryAlias: 'cyber_ghost_99',
        fullNameCandidate: 'Ghost Analyst',
        avatarUrl: 'https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?w=150&auto=format&fit=crop&q=80',
        locationCandidate: 'Europe / Remote',
        overallRiskScore: 64,
        riskLevel: 'MEDIUM',
        confidenceScore: 91,
        totalProfilesFound: 6,
        totalBreachesFound: 2,
        firstSeenDate: '2018-11-02',
        lastSeenDate: '2026-07-29',
        summaryText: 'Identical username active on GitHub, Steam, HackerNews, Reddit, Twitch, and Discord servers. Reused handle allows high confidence identity clustering.'
      },
      profiles: [
        {
          id: 'pu1',
          platform: 'GitHub',
          category: 'Developer',
          username: 'cyber_ghost_99',
          url: 'https://github.com/cyber_ghost_99',
          status: 'VERIFIED',
          accountAge: '6 years',
          metadata: { 'Starred Repos': '142', 'Language': 'Rust / Python' },
          confidence: 96
        },
        {
          id: 'pu2',
          platform: 'Steam',
          category: 'Gaming',
          username: 'cyber_ghost_99',
          url: 'https://steamcommunity.com/id/cyber_ghost_99',
          status: 'FOUND',
          metadata: { 'Steam Level': '24', 'Games Owned': '88', 'Badges': 'Security Enthusiast' },
          confidence: 92
        },
        {
          id: 'pu3',
          platform: 'HackerNews',
          category: 'Forum',
          username: 'cyber_ghost_99',
          url: 'https://news.ycombinator.com/user?id=cyber_ghost_99',
          status: 'FOUND',
          metadata: { 'Karma': '840', 'Created': '2019' },
          confidence: 94
        },
        {
          id: 'pu4',
          platform: 'Twitch',
          category: 'Social',
          username: 'cyber_ghost_99',
          url: 'https://twitch.tv/cyber_ghost_99',
          status: 'FOUND',
          metadata: { 'Followers': '320', 'Category': 'Software & Game Dev' },
          confidence: 88
        },
        {
          id: 'pu5',
          platform: 'Reddit',
          category: 'Forum',
          username: 'cyber_ghost_99',
          url: 'https://reddit.com/user/cyber_ghost_99',
          status: 'FOUND',
          metadata: { 'Karma': '3.4k', 'Active Subreddits': 'r/cybersecurity, r/rust' },
          confidence: 90
        },
        {
          id: 'pu6',
          platform: 'Dev.to',
          category: 'Developer',
          username: 'cyber_ghost_99',
          url: 'https://dev.to/cyber_ghost_99',
          status: 'FOUND',
          metadata: { 'Articles Published': '5' },
          confidence: 85
        }
      ],
      breaches: [
        {
          id: 'ub1',
          title: 'Wattpad Breach (2020)',
          domain: 'wattpad.com',
          breachDate: '2020-06-29',
          addedDate: '2020-07-20',
          pwnCount: 268000000,
          dataClasses: ['Usernames', 'Passwords', 'Email addresses', 'IP addresses'],
          isVerified: true,
          isFabricated: false,
          isSensitive: false,
          isRetired: false,
          isSpamList: false,
          description: '268 million user accounts exposed including usernames, emails, hashed passwords.',
          severity: 'HIGH',
          exposedFields: ['Username', 'Email', 'Password Hash']
        }
      ],
      threatVectors: [
        { category: 'Username Reuse Clustering', score: 90, description: 'Reusing the unique handle "cyber_ghost_99" across gaming, forums, and code repos links all anonymous personas into a single target graph.', status: 'ALERT' },
        { category: 'Social Engineering Exposure', score: 60, description: 'Detailed interests revealed on HackerNews and Steam.', status: 'WARNING' }
      ],
      timeline: [
        { id: 'ut1', date: '2018-11-02', title: 'Steam & GitHub Registrations', category: 'Account Creation', description: 'Created accounts using username handle.', source: 'Platform APIs' },
        { id: 'ut2', date: '2020-06-29', title: 'Exposed in Wattpad Leak', category: 'Data Breach', description: 'Handle matched leak record.', source: 'Wattpad Breach', severity: 'warning' }
      ],
      recommendations: [
        'Use unique randomized usernames for distinct security contexts (e.g., gaming vs work vs darknet research).',
        'Remove cross-linking URLs from Steam and GitHub profiles if seeking privacy.'
      ],
      networkGraph: {
        nodes: [
          { id: 'n-user', label: 'cyber_ghost_99', type: 'target', risk: 'MEDIUM' },
          { id: 'n-gh', label: 'GitHub', type: 'profile', risk: 'LOW' },
          { id: 'n-st', label: 'Steam', type: 'profile', risk: 'LOW' },
          { id: 'n-hn', label: 'HackerNews', type: 'profile', risk: 'LOW' },
          { id: 'n-b', label: 'Wattpad Breach', type: 'breach', risk: 'HIGH' }
        ],
        links: [
          { source: 'n-user', target: 'n-gh', label: 'Exact Match' },
          { source: 'n-user', target: 'n-st', label: 'Exact Match' },
          { source: 'n-user', target: 'n-hn', label: 'Exact Match' },
          { source: 'n-user', target: 'n-b', label: 'Leak Match' }
        ]
      }
    }
  }
];
